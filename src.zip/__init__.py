"""
Ecological Analysis Workshop Package
=====================================

A comprehensive toolkit for teaching ecological analyses in global health research.
Developed for PhD workshops in Global Health Informatics.

Modules:
--------
- data_acquisition: Robust World Bank data fetching with wbgapi
- eda: Exploratory data analysis with ecological fallacy demonstrations
- clustering: K-means clustering of countries by development profiles
- spatial: Spatial autocorrelation analysis (Moran's I, LISA, hot/cold spots)
- regression: Hierarchical regression with full diagnostics
- ml_models: PyCaret AutoML for predictive modelling
- policy_simulation: In-silico policy experiments with uncertainty
- visualisation: Publication-ready plots (funnel, bubble, choropleth)
- dashboard: Interactive Gradio teaching interface
- utils: Helper functions and data dictionaries

Author: Global Health Informatics Workshop
Version: 2.0.0
"""

__version__ = "2.0.0"
__author__ = "Global Health Informatics Workshop"

from .data_acquisition import fetch_world_bank_data, create_data_dictionary
from .eda import (
    demonstrate_ecological_fallacy,
    analyze_correlations_hierarchical,
    create_scatter_matrix
)
from .clustering import cluster_countries, plot_cluster_results, find_optimal_clusters
from .spatial import (
    create_spatial_weights,
    calculate_moran_i,
    calculate_lisa,
    plot_moran_scatterplot,
    plot_lisa_map,
    plot_hotspot_map
)
from .regression import (
    build_progressive_models,
    regression_diagnostics,
    sensitivity_analysis,
    robust_standard_errors
)
from .ml_models import setup_pycaret, compare_models, interpret_model
from .policy_simulation import (
    run_policy_simulation,
    run_policy_simulation_with_uncertainty,
    create_country_report_card
)
from .visualisation import (
    create_funnel_plot,
    create_bubble_plot,
    create_world_map,
    create_dag_visualisation
)

__all__ = [
    # Data
    'fetch_world_bank_data',
    'create_data_dictionary',
    # EDA
    'demonstrate_ecological_fallacy',
    'analyze_correlations_hierarchical',
    'create_scatter_matrix',
    # Clustering
    'cluster_countries',
    'plot_cluster_results',
    'find_optimal_clusters',
    # Spatial
    'create_spatial_weights',
    'calculate_moran_i',
    'calculate_lisa',
    'plot_moran_scatterplot',
    'plot_lisa_map',
    'plot_hotspot_map',
    # Regression
    'build_progressive_models',
    'regression_diagnostics',
    'sensitivity_analysis',
    'robust_standard_errors',
    # ML
    'setup_pycaret',
    'compare_models',
    'interpret_model',
    # Policy
    'run_policy_simulation',
    'run_policy_simulation_with_uncertainty',
    'create_country_report_card',
    # Visualisation
    'create_funnel_plot',
    'create_bubble_plot',
    'create_world_map',
    'create_dag_visualisation',
]
