"""
Clustering Module
=================

K-means and hierarchical clustering to identify natural groupings of
countries by development and health profiles.

TEACHING NOTES:
--------------
1. Clustering is EXPLORATORY - it reveals structure in data, not causation.

2. The number of clusters (k) is a research choice. Use the elbow method
   and silhouette scores as guides, but also consider interpretability.

3. Clusters often correspond to:
   - Income groups (Low, Middle, High)
   - Geographic regions
   - Epidemiological transition stages

4. IMPORTANT: Clustering countries by determinants can introduce
   collider bias if you then control for clusters in regression.
   Use clusters for description, not as regression covariates.

Key References:
- Omran, A.R. (1971). The epidemiologic transition theory.
- Santosa, A. et al. (2014). The development and experience of epidemiological
  transition theory over four decades.

Dependencies:
    pip install pandas numpy matplotlib seaborn plotly scikit-learn
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.cluster import KMeans, AgglomerativeClustering
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score, calinski_harabasz_score
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from typing import List, Optional, Tuple
import warnings

warnings.filterwarnings('ignore')


# =============================================================================
# OPTIMAL CLUSTER SELECTION
# =============================================================================

def find_optimal_clusters(
    df: pd.DataFrame,
    features: Optional[List[str]] = None,
    k_range: Tuple[int, int] = (2, 10),
    show_plot: bool = True
) -> Tuple[int, go.Figure]:
    """
    Determines optimal number of clusters using multiple criteria.
    
    TEACHING SCRIPT:
    ---------------
    "How do we decide the 'right' number of clusters?
    
    There's no single correct answer, but we use several metrics:
    
    1. ELBOW METHOD (Inertia): Look for where the curve 'bends'
       - Inertia = sum of squared distances to cluster centres
       - More clusters always reduces inertia, but with diminishing returns
    
    2. SILHOUETTE SCORE: Measures cluster coherence (-1 to +1)
       - High score = observations are well-matched to their cluster
       - Look for the maximum
    
    3. INTERPRETABILITY: Can you name the clusters meaningfully?
       - 'High-income, Low-mortality' vs 'Cluster 3' "
    
    Parameters
    ----------
    df : pd.DataFrame
        Dataset with features for clustering
    features : list, optional
        Features to use (default: economic and health indicators)
    k_range : tuple
        Range of k values to test
    show_plot : bool
        Whether to display the diagnostic plot
        
    Returns
    -------
    tuple : (optimal_k, diagnostic_figure)
    """
    
    if features is None:
        features = ['gni_per_capita', 'crude_death_rate', 'adult_literacy',
                    'physicians_density', 'urban_population']
    
    # Filter to available features
    features = [f for f in features if f in df.columns]
    
    if len(features) < 2:
        raise ValueError("Need at least 2 features for clustering")
    
    # Prepare data
    df_cluster = df[features].dropna()
    
    if len(df_cluster) < k_range[1]:
        k_range = (2, len(df_cluster) // 2)
    
    # Standardise features
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(df_cluster)
    
    # Calculate metrics for each k
    k_values = list(range(k_range[0], k_range[1] + 1))
    inertias = []
    silhouettes = []
    calinski = []
    
    for k in k_values:
        kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
        labels = kmeans.fit_predict(X_scaled)
        
        inertias.append(kmeans.inertia_)
        silhouettes.append(silhouette_score(X_scaled, labels))
        calinski.append(calinski_harabasz_score(X_scaled, labels))
    
    # Find optimal k (maximum silhouette score)
    optimal_k = k_values[np.argmax(silhouettes)]
    
    # Create diagnostic plot
    fig = make_subplots(
        rows=1, cols=3,
        subplot_titles=(
            '<b>Elbow Method (Inertia)</b>',
            '<b>Silhouette Score</b>',
            '<b>Calinski-Harabasz Index</b>'
        )
    )
    
    # Elbow plot
    fig.add_trace(
        go.Scatter(
            x=k_values, y=inertias,
            mode='lines+markers',
            marker=dict(size=10),
            line=dict(width=2),
            name='Inertia'
        ),
        row=1, col=1
    )
    
    # Silhouette plot
    fig.add_trace(
        go.Scatter(
            x=k_values, y=silhouettes,
            mode='lines+markers',
            marker=dict(size=10, color='green'),
            line=dict(width=2, color='green'),
            name='Silhouette'
        ),
        row=1, col=2
    )
    
    # Mark optimal
    fig.add_trace(
        go.Scatter(
            x=[optimal_k], y=[silhouettes[k_values.index(optimal_k)]],
            mode='markers',
            marker=dict(size=20, color='red', symbol='star'),
            name=f'Optimal k={optimal_k}'
        ),
        row=1, col=2
    )
    
    # Calinski-Harabasz plot
    fig.add_trace(
        go.Scatter(
            x=k_values, y=calinski,
            mode='lines+markers',
            marker=dict(size=10, color='purple'),
            line=dict(width=2, color='purple'),
            name='Calinski-Harabasz'
        ),
        row=1, col=3
    )
    
    fig.update_layout(
        height=400,
        title_text=f"<b>Cluster Selection Diagnostics</b><br>" +
                   f"<span style='color:green'>Optimal k = {optimal_k} (by silhouette score)</span>",
        showlegend=False
    )
    
    fig.update_xaxes(title_text="Number of Clusters (k)")
    fig.update_yaxes(title_text="Inertia", row=1, col=1)
    fig.update_yaxes(title_text="Silhouette Score", row=1, col=2)
    fig.update_yaxes(title_text="CH Index", row=1, col=3)
    
    if show_plot:
        fig.show()
    
    print(f"\n📊 CLUSTER SELECTION SUMMARY")
    print("=" * 50)
    print(f"Optimal k by silhouette score: {optimal_k}")
    print(f"Silhouette score at k={optimal_k}: {silhouettes[k_values.index(optimal_k)]:.3f}")
    print("\nInterpretation guide:")
    print("  Silhouette > 0.5: Strong structure")
    print("  Silhouette 0.25-0.5: Moderate structure")
    print("  Silhouette < 0.25: Weak structure")
    print("=" * 50)
    
    return optimal_k, fig


# =============================================================================
# CLUSTERING FUNCTIONS
# =============================================================================

def cluster_countries(
    df: pd.DataFrame,
    features: Optional[List[str]] = None,
    n_clusters: int = 3,
    method: str = 'kmeans'
) -> pd.DataFrame:
    """
    Clusters countries based on development and health indicators.
    
    TEACHING NOTE:
    -------------
    We typically find 3-4 natural clusters corresponding to:
    
    1. HIGH-INCOME, LOW-MORTALITY: Western Europe, Japan, Australia
       - High GNI, high literacy, low communicable disease
       - Challenge: Ageing populations, NCDs
    
    2. MIDDLE-INCOME, TRANSITIONAL: Brazil, China, South Africa
       - Moderate GNI, improving indicators
       - "Double burden" of disease
    
    3. LOW-INCOME, HIGH-MORTALITY: Much of Sub-Saharan Africa
       - Low GNI, infrastructure gaps
       - High communicable disease burden
    
    Parameters
    ----------
    df : pd.DataFrame
        Dataset with country data
    features : list, optional
        Features for clustering
    n_clusters : int
        Number of clusters
    method : str
        'kmeans' or 'hierarchical'
        
    Returns
    -------
    pd.DataFrame : Original data with cluster assignments
    """
    
    if features is None:
        features = ['gni_per_capita', 'crude_death_rate', 'adult_literacy',
                    'physicians_density', 'urban_population']
    
    features = [f for f in features if f in df.columns]
    
    # Create copy to avoid modifying original
    df_result = df.copy()
    
    # Prepare data (drop rows with missing features)
    df_cluster = df_result[features].dropna()
    valid_idx = df_cluster.index
    
    # Standardise
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(df_cluster)
    
    # Cluster
    if method == 'kmeans':
        model = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
    elif method == 'hierarchical':
        model = AgglomerativeClustering(n_clusters=n_clusters)
    else:
        raise ValueError(f"Unknown method: {method}")
    
    labels = model.fit_predict(X_scaled)
    
    # Add cluster labels
    df_result['cluster'] = np.nan
    df_result.loc[valid_idx, 'cluster'] = labels
    
    # Create meaningful cluster names based on characteristics
    cluster_profiles = df_result.groupby('cluster')[features].mean()
    
    # Determine cluster names based on GNI and mortality
    cluster_names = {}
    for cluster_id in range(n_clusters):
        if cluster_id not in cluster_profiles.index:
            continue
            
        profile = cluster_profiles.loc[cluster_id]
        gni_rank = cluster_profiles['gni_per_capita'].rank()[cluster_id]
        
        if gni_rank <= n_clusters / 3:
            cluster_names[cluster_id] = f"Low Development (Cluster {cluster_id})"
        elif gni_rank >= n_clusters * 2 / 3:
            cluster_names[cluster_id] = f"High Development (Cluster {cluster_id})"
        else:
            cluster_names[cluster_id] = f"Middle Development (Cluster {cluster_id})"
    
    df_result['cluster_name'] = df_result['cluster'].map(cluster_names)
    
    # Print summary
    print("\n📊 CLUSTER SUMMARY")
    print("=" * 60)
    print(f"Method: {method.upper()}")
    print(f"Number of clusters: {n_clusters}")
    print(f"Countries clustered: {len(valid_idx)} / {len(df_result)}")
    print("\nCluster sizes:")
    print(df_result['cluster_name'].value_counts())
    print("\nCluster profiles (means):")
    print(cluster_profiles.round(2))
    print("=" * 60)
    
    return df_result


def plot_cluster_results(
    df: pd.DataFrame,
    x_var: str = 'gni_per_capita',
    y_var: str = 'crude_death_rate',
    log_x: bool = True
) -> go.Figure:
    """
    Creates interactive visualisation of cluster results.
    
    TEACHING NOTE:
    -------------
    This plot helps students see:
    1. How well-separated the clusters are
    2. Which countries are "boundary cases"
    3. Whether clusters align with regions/income groups
    
    Parameters
    ----------
    df : pd.DataFrame
        Data with cluster assignments
    x_var : str
        Variable for x-axis
    y_var : str
        Variable for y-axis
    log_x : bool
        Whether to use log scale for x-axis
        
    Returns
    -------
    go.Figure : Interactive scatter plot
    """
    
    if 'cluster_name' not in df.columns:
        raise ValueError("Run cluster_countries() first")
    
    # Filter to clustered observations
    df_plot = df.dropna(subset=['cluster_name', x_var, y_var])
    
    fig = px.scatter(
        df_plot,
        x=x_var,
        y=y_var,
        color='cluster_name',
        hover_name='country' if 'country' in df_plot.columns else None,
        hover_data=['region'] if 'region' in df_plot.columns else None,
        log_x=log_x,
        title=f"<b>Country Clusters: {x_var.replace('_', ' ').title()} vs " +
              f"{y_var.replace('_', ' ').title()}</b>",
        labels={
            x_var: x_var.replace('_', ' ').title() + (' (Log Scale)' if log_x else ''),
            y_var: y_var.replace('_', ' ').title()
        },
        color_discrete_sequence=px.colors.qualitative.Set1
    )
    
    fig.update_traces(marker=dict(size=12, line=dict(width=1, color='white')))
    fig.update_layout(
        height=600,
        legend_title_text='Cluster'
    )
    
    return fig


def plot_cluster_profiles(df: pd.DataFrame, features: Optional[List[str]] = None) -> go.Figure:
    """
    Creates radar/spider chart showing cluster profiles.
    
    TEACHING NOTE:
    -------------
    Radar charts help visualise multi-dimensional cluster profiles.
    Students can quickly see how clusters differ across indicators.
    
    Parameters
    ----------
    df : pd.DataFrame
        Data with cluster assignments
    features : list, optional
        Features to include in profile
        
    Returns
    -------
    go.Figure : Radar chart of cluster profiles
    """
    
    if 'cluster_name' not in df.columns:
        raise ValueError("Run cluster_countries() first")
    
    if features is None:
        features = ['gni_per_capita', 'crude_death_rate', 'adult_literacy',
                    'physicians_density', 'safe_water']
    
    features = [f for f in features if f in df.columns]
    
    # Calculate standardised means by cluster
    cluster_means = df.groupby('cluster_name')[features].mean()
    
    # Standardise for comparison
    scaler = StandardScaler()
    cluster_means_std = pd.DataFrame(
        scaler.fit_transform(cluster_means),
        index=cluster_means.index,
        columns=cluster_means.columns
    )
    
    # Create radar chart
    fig = go.Figure()
    
    colors = px.colors.qualitative.Set1
    
    for i, (cluster, row) in enumerate(cluster_means_std.iterrows()):
        fig.add_trace(go.Scatterpolar(
            r=list(row.values) + [row.values[0]],  # Close the polygon
            theta=list(features) + [features[0]],
            fill='toself',
            name=cluster,
            line_color=colors[i % len(colors)],
            opacity=0.6
        ))
    
    fig.update_layout(
        polar=dict(
            radialaxis=dict(
                visible=True,
                range=[-2, 2]
            )
        ),
        showlegend=True,
        title="<b>Cluster Profiles (Standardised)</b><br>" +
              "<span style='font-size:12px'>Centre = Low, Outer = High (relative to global mean)</span>",
        height=600
    )
    
    return fig


def create_cluster_dendrogram(
    df: pd.DataFrame,
    features: Optional[List[str]] = None,
    n_countries: int = 50
) -> plt.Figure:
    """
    Creates hierarchical clustering dendrogram.
    
    TEACHING NOTE:
    -------------
    Dendrograms show the hierarchical relationships between countries.
    The height at which clusters join indicates how different they are.
    
    This can reveal:
    - Natural groupings at different levels
    - Which countries are most similar
    - Outliers that don't fit any group well
    
    Parameters
    ----------
    df : pd.DataFrame
        Dataset
    features : list, optional
        Features for clustering
    n_countries : int
        Number of countries to include (for readability)
        
    Returns
    -------
    plt.Figure : Dendrogram figure
    """
    from scipy.cluster.hierarchy import dendrogram, linkage
    
    if features is None:
        features = ['gni_per_capita', 'crude_death_rate', 'adult_literacy',
                    'physicians_density']
    
    features = [f for f in features if f in df.columns]
    
    # Prepare data
    df_dendro = df[['country'] + features].dropna()
    
    if len(df_dendro) > n_countries:
        df_dendro = df_dendro.sample(n=n_countries, random_state=42)
    
    # Standardise
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(df_dendro[features])
    
    # Compute linkage
    Z = linkage(X_scaled, method='ward')
    
    # Plot
    fig, ax = plt.subplots(figsize=(14, 8))
    
    dendrogram(
        Z,
        labels=df_dendro['country'].values,
        leaf_rotation=90,
        leaf_font_size=8,
        ax=ax
    )
    
    ax.set_title('Hierarchical Clustering of Countries\n(Ward linkage)', fontsize=14)
    ax.set_xlabel('Country')
    ax.set_ylabel('Distance')
    
    plt.tight_layout()
    
    return fig


# =============================================================================
# MAIN EXECUTION (for testing)
# =============================================================================

if __name__ == "__main__":
    print("Testing clustering module...")
    print("This module requires data from data_acquisition module.")
    print("See notebooks for usage examples.")
