"""
Policy Simulation Module
========================

In-silico policy experiments with uncertainty quantification for
evaluating hypothetical interventions.

TEACHING NOTES:
--------------
1. WHAT IS POLICY SIMULATION?
   Using our predictive model to ask "what if" questions:
   - What if we increased literacy by 20%?
   - What if we doubled physician density?
   - Which intervention gives the biggest mortality reduction?

2. CRITICAL CAVEATS:
   - These are PREDICTIONS, not causal effects
   - Models may not extrapolate well (out-of-distribution)
   - Assumes interventions don't change other variables
   - Real policy effects may differ due to implementation

3. UNCERTAINTY QUANTIFICATION:
   - Point estimates are misleading without uncertainty
   - Bootstrap provides confidence intervals
   - Wide intervals → less reliable predictions

4. COST-EFFECTIVENESS (Advanced):
   - Mortality reduction per dollar spent
   - Requires external cost data
   - Beyond scope of this workshop

Key References:
- Greenland, S. (2005). Multiple-bias modelling for observational studies.
- Saltelli, A. et al. (2008). Global Sensitivity Analysis.
- Vickers, A.J. (2008). Decision curve analysis.

Dependencies:
    pip install pandas numpy matplotlib plotly
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from typing import Dict, List, Optional, Tuple, Any, Callable
import warnings

warnings.filterwarnings('ignore')

# Try to import PyCaret
try:
    from pycaret.regression import predict_model
    PYCARET_AVAILABLE = True
except ImportError:
    PYCARET_AVAILABLE = False


# =============================================================================
# BASIC POLICY SIMULATION
# =============================================================================

def run_policy_simulation(
    model: Any,
    df: pd.DataFrame,
    variable: str,
    percent_change: float,
    cap_at_100: bool = True
) -> Dict:
    """
    Simulates a policy intervention by modifying a single variable.
    
    TEACHING SCRIPT:
    ---------------
    "Let's play 'Health Minister for a Day':
    
    You have a limited budget and must choose ONE intervention:
    A) Economic boost (increase GNI by 20%)
    B) Education reform (increase literacy by 20%)
    C) Health system investment (increase physicians by 20%)
    
    Our model predicts mortality under each scenario.
    But remember: these are MODEL PREDICTIONS, not guaranteed outcomes!
    
    The simulation:
    1. Takes current data for all countries
    2. Modifies ONE variable (e.g., +20% literacy)
    3. Predicts new mortality rates
    4. Calculates average improvement"
    
    Parameters
    ----------
    model : Any
        Trained prediction model
    df : pd.DataFrame
        Current data
    variable : str
        Variable to modify
    percent_change : float
        Percentage change (0.20 = 20% increase)
    cap_at_100 : bool
        Whether to cap percentage variables at 100
        
    Returns
    -------
    dict : Simulation results
    """
    
    if variable not in df.columns:
        raise ValueError(f"Variable '{variable}' not found in data")
    
    # Create copies of data
    baseline_data = df.copy()
    intervention_data = df.copy()
    
    # Apply intervention
    original_values = intervention_data[variable].copy()
    new_values = original_values * (1 + percent_change)
    
    # Cap at 100 for percentage variables
    percentage_indicators = ['literacy', 'immunisation', 'immunization', 'access',
                            'sanitation', 'water', 'population', 'prevalence']
    
    if cap_at_100 and any(ind in variable.lower() for ind in percentage_indicators):
        new_values = new_values.clip(upper=100)
    
    intervention_data[variable] = new_values
    
    # Make predictions
    try:
        baseline_pred = predict_model(model, data=baseline_data)['prediction_label']
        intervention_pred = predict_model(model, data=intervention_data)['prediction_label']
    except Exception as e:
        raise RuntimeError(f"Prediction failed: {e}")
    
    # Calculate impacts
    individual_impacts = baseline_pred - intervention_pred
    
    results = {
        'variable': variable,
        'percent_change': percent_change * 100,
        'mean_mortality_reduction': individual_impacts.mean(),
        'median_mortality_reduction': individual_impacts.median(),
        'std_mortality_reduction': individual_impacts.std(),
        'min_reduction': individual_impacts.min(),
        'max_reduction': individual_impacts.max(),
        'countries_improved': (individual_impacts > 0).sum(),
        'countries_worsened': (individual_impacts < 0).sum(),
        'baseline_mean_mortality': baseline_pred.mean(),
        'intervention_mean_mortality': intervention_pred.mean(),
        'individual_impacts': individual_impacts.values
    }
    
    return results


def run_policy_simulation_with_uncertainty(
    model: Any,
    df: pd.DataFrame,
    variable: str,
    percent_change: float,
    n_bootstrap: int = 200,
    confidence_level: float = 0.95,
    cap_at_100: bool = True
) -> Dict:
    """
    Policy simulation with bootstrapped confidence intervals.
    
    TEACHING SCRIPT:
    ---------------
    "Point estimates are dangerous - they hide uncertainty!
    
    A simulation might predict '0.5 fewer deaths per 1000'.
    But how confident are we? The true effect could be anywhere
    from 0.1 to 0.9.
    
    BOOTSTRAP provides confidence intervals:
    1. Resample countries WITH replacement (like a new sample)
    2. Run simulation on resampled data
    3. Repeat 200+ times
    4. Take the 2.5th and 97.5th percentiles
    
    Wide confidence intervals mean:
    - Less certainty about the effect
    - Need more data or better models
    - Be cautious about policy recommendations"
    
    Parameters
    ----------
    model : Any
        Trained prediction model
    df : pd.DataFrame
        Current data
    variable : str
        Variable to modify
    percent_change : float
        Percentage change
    n_bootstrap : int
        Number of bootstrap iterations
    confidence_level : float
        Confidence level for intervals
    cap_at_100 : bool
        Whether to cap percentage variables
        
    Returns
    -------
    dict : Simulation results with confidence intervals
    """
    
    if variable not in df.columns:
        raise ValueError(f"Variable '{variable}' not found in data")
    
    print(f"\n🔄 Running bootstrap simulation ({n_bootstrap} iterations)...")
    
    bootstrap_means = []
    
    for i in range(n_bootstrap):
        # Resample with replacement
        sample = df.sample(frac=1, replace=True)
        
        # Create intervention data
        baseline_data = sample.copy()
        intervention_data = sample.copy()
        
        # Apply intervention
        new_values = intervention_data[variable] * (1 + percent_change)
        
        percentage_indicators = ['literacy', 'immunisation', 'immunization', 'access',
                                'sanitation', 'water', 'population', 'prevalence']
        
        if cap_at_100 and any(ind in variable.lower() for ind in percentage_indicators):
            new_values = new_values.clip(upper=100)
        
        intervention_data[variable] = new_values
        
        # Predict
        try:
            baseline_pred = predict_model(model, data=baseline_data)['prediction_label']
            intervention_pred = predict_model(model, data=intervention_data)['prediction_label']
            
            impact = (baseline_pred - intervention_pred).mean()
            bootstrap_means.append(impact)
            
        except:
            continue
        
        # Progress indicator
        if (i + 1) % 50 == 0:
            print(f"   Completed {i + 1} / {n_bootstrap} iterations")
    
    bootstrap_means = np.array(bootstrap_means)
    
    # Calculate confidence intervals
    alpha = 1 - confidence_level
    ci_lower = np.percentile(bootstrap_means, alpha / 2 * 100)
    ci_upper = np.percentile(bootstrap_means, (1 - alpha / 2) * 100)
    
    # Also run point estimate for individual countries
    base_results = run_policy_simulation(model, df, variable, percent_change, cap_at_100)
    
    results = {
        'variable': variable,
        'percent_change': percent_change * 100,
        'point_estimate': base_results['mean_mortality_reduction'],
        'bootstrap_mean': np.mean(bootstrap_means),
        'bootstrap_std': np.std(bootstrap_means),
        f'ci_{int(confidence_level*100)}_lower': ci_lower,
        f'ci_{int(confidence_level*100)}_upper': ci_upper,
        'n_bootstrap': len(bootstrap_means),
        'bootstrap_values': bootstrap_means,
        'countries_improved': base_results['countries_improved'],
        'countries_worsened': base_results['countries_worsened']
    }
    
    print(f"\n✅ Simulation complete!")
    print(f"   Effect: {results['point_estimate']:.4f} [{ci_lower:.4f}, {ci_upper:.4f}]")
    
    return results


# =============================================================================
# COMPARATIVE POLICY ANALYSIS
# =============================================================================

def compare_policy_scenarios(
    model: Any,
    df: pd.DataFrame,
    scenarios: Dict[str, Tuple[str, float]],
    with_uncertainty: bool = True,
    n_bootstrap: int = 100
) -> pd.DataFrame:
    """
    Compares multiple policy scenarios side-by-side.
    
    TEACHING SCRIPT:
    ---------------
    "Now let's compare interventions systematically:
    
    | Policy                      | Mortality Reduction | 95% CI       |
    |-----------------------------|---------------------|--------------|
    | +20% GNI                    | 0.32                | [0.15, 0.49] |
    | +20% Literacy               | 0.58                | [0.42, 0.74] |
    | +20% Physicians             | 0.25                | [0.08, 0.42] |
    
    KEY INSIGHTS:
    1. Which intervention has the LARGEST effect?
    2. Which has the NARROWEST confidence interval (most certain)?
    3. Do any intervals overlap zero (uncertain direction)?
    
    POLICY RECOMMENDATION:
    Consider both effect size AND certainty!"
    
    Parameters
    ----------
    model : Any
        Trained prediction model
    df : pd.DataFrame
        Current data
    scenarios : dict
        {name: (variable, percent_change)}
    with_uncertainty : bool
        Whether to calculate bootstrap CIs
    n_bootstrap : int
        Bootstrap iterations if with_uncertainty=True
        
    Returns
    -------
    pd.DataFrame : Comparison of all scenarios
    """
    
    print("\n" + "=" * 70)
    print("📊 COMPARATIVE POLICY ANALYSIS")
    print("=" * 70)
    
    results = []
    
    for scenario_name, (variable, pct_change) in scenarios.items():
        print(f"\n🔄 Analysing: {scenario_name}...")
        
        if variable not in df.columns:
            print(f"   ⚠️ Skipping - variable '{variable}' not found")
            continue
        
        try:
            if with_uncertainty:
                sim_results = run_policy_simulation_with_uncertainty(
                    model, df, variable, pct_change, 
                    n_bootstrap=n_bootstrap
                )
                
                results.append({
                    'Scenario': scenario_name,
                    'Variable': variable,
                    'Change (%)': pct_change * 100,
                    'Mortality Reduction': sim_results['point_estimate'],
                    'CI Lower': sim_results['ci_95_lower'],
                    'CI Upper': sim_results['ci_95_upper'],
                    'Uncertainty': sim_results['bootstrap_std'],
                    'Significance': 'Significant' if (
                        sim_results['ci_95_lower'] > 0 or sim_results['ci_95_upper'] < 0
                    ) else 'Not Significant'
                })
            else:
                sim_results = run_policy_simulation(
                    model, df, variable, pct_change
                )
                
                results.append({
                    'Scenario': scenario_name,
                    'Variable': variable,
                    'Change (%)': pct_change * 100,
                    'Mortality Reduction': sim_results['mean_mortality_reduction'],
                    'CI Lower': None,
                    'CI Upper': None,
                    'Uncertainty': sim_results['std_mortality_reduction'],
                    'Significance': 'N/A'
                })
                
        except Exception as e:
            print(f"   ⚠️ Error: {str(e)}")
            continue
    
    results_df = pd.DataFrame(results)
    
    if len(results_df) > 0:
        # Sort by mortality reduction
        results_df = results_df.sort_values('Mortality Reduction', ascending=False)
        
        print("\n" + "=" * 70)
        print("📋 POLICY COMPARISON RESULTS")
        print("=" * 70)
        print(results_df.to_string(index=False, float_format=lambda x: f"{x:.4f}"))
        
        # Identify best policy
        best = results_df.iloc[0]
        print(f"\n🏆 RECOMMENDED: {best['Scenario']}")
        print(f"   Expected mortality reduction: {best['Mortality Reduction']:.3f} per 1,000")
        
        if with_uncertainty and best['CI Lower'] is not None:
            print(f"   95% CI: [{best['CI Lower']:.3f}, {best['CI Upper']:.3f}]")
        
        print("=" * 70)
    
    return results_df


def plot_policy_comparison(results_df: pd.DataFrame) -> go.Figure:
    """
    Creates forest plot of policy comparison results.
    
    Parameters
    ----------
    results_df : pd.DataFrame
        Results from compare_policy_scenarios
        
    Returns
    -------
    go.Figure : Forest plot
    """
    
    fig = go.Figure()
    
    # Add error bars for each scenario
    for i, row in results_df.iterrows():
        color = '#27ae60' if row['Mortality Reduction'] > 0 else '#e74c3c'
        
        # Point estimate
        fig.add_trace(go.Scatter(
            x=[row['Mortality Reduction']],
            y=[row['Scenario']],
            mode='markers',
            marker=dict(size=15, color=color),
            name=row['Scenario'],
            showlegend=False
        ))
        
        # Confidence interval (if available)
        if pd.notna(row.get('CI Lower')) and pd.notna(row.get('CI Upper')):
            fig.add_trace(go.Scatter(
                x=[row['CI Lower'], row['CI Upper']],
                y=[row['Scenario'], row['Scenario']],
                mode='lines',
                line=dict(color=color, width=3),
                showlegend=False
            ))
    
    # Add vertical line at zero
    fig.add_vline(x=0, line_dash='dash', line_color='gray')
    
    fig.update_layout(
        title='<b>Policy Impact Comparison</b><br>' +
              '<span style="font-size:12px">Mortality Reduction per 1,000 (with 95% CI)</span>',
        xaxis_title='Mortality Reduction (per 1,000)',
        yaxis_title='Policy Scenario',
        height=400,
        yaxis={'categoryorder': 'total ascending'}
    )
    
    return fig


# =============================================================================
# COUNTRY REPORT CARDS
# =============================================================================

def create_country_report_card(
    model: Any,
    df: pd.DataFrame,
    country: str,
    scenarios: Dict[str, Tuple[str, float]],
    id_col: str = 'country'
) -> Dict:
    """
    Creates a personalised policy report card for a specific country.
    
    TEACHING SCRIPT:
    ---------------
    "Generic policy recommendations ignore country context.
    
    A country-specific report card shows:
    1. Current indicators vs. global averages
    2. Predicted impact of each intervention
    3. Which policies would help THIS country most
    
    Example: Ethiopia might benefit most from healthcare investment,
    while Brazil might benefit from NCD prevention programs."
    
    Parameters
    ----------
    model : Any
        Trained model
    df : pd.DataFrame
        Data
    country : str
        Country name or ISO code
    scenarios : dict
        Policy scenarios to evaluate
    id_col : str
        Column containing country identifier
        
    Returns
    -------
    dict : Country-specific report card
    """
    
    # Find country data
    if id_col not in df.columns:
        raise ValueError(f"ID column '{id_col}' not found")
    
    country_data = df[df[id_col] == country]
    
    if len(country_data) == 0:
        # Try partial match
        matches = df[df[id_col].str.contains(country, case=False, na=False)]
        if len(matches) > 0:
            country_data = matches.iloc[[0]]
            country = country_data[id_col].values[0]
        else:
            raise ValueError(f"Country '{country}' not found")
    
    country_data = country_data.iloc[[0]]  # Take first row
    
    print("\n" + "=" * 70)
    print(f"📋 COUNTRY REPORT CARD: {country.upper()}")
    print("=" * 70)
    
    # Current status
    report = {
        'country': country,
        'current_indicators': {},
        'policy_impacts': []
    }
    
    # Compare to global averages
    key_indicators = ['crude_death_rate', 'gni_per_capita', 'adult_literacy',
                     'physicians_density', 'safe_water', 'basic_sanitation']
    
    print("\n📊 CURRENT STATUS (vs. Global Average):")
    print("-" * 50)
    
    for ind in key_indicators:
        if ind in df.columns:
            country_val = country_data[ind].values[0]
            global_mean = df[ind].mean()
            
            if pd.notna(country_val):
                pct_diff = (country_val - global_mean) / global_mean * 100
                symbol = "↑" if pct_diff > 0 else "↓"
                status = "above" if pct_diff > 0 else "below"
                
                print(f"   {ind}: {country_val:.2f} ({symbol} {abs(pct_diff):.1f}% {status} global avg)")
                
                report['current_indicators'][ind] = {
                    'value': country_val,
                    'global_mean': global_mean,
                    'percent_difference': pct_diff
                }
    
    # Evaluate policies for this country
    print("\n💊 PREDICTED POLICY IMPACTS:")
    print("-" * 50)
    
    for scenario_name, (variable, pct_change) in scenarios.items():
        if variable not in df.columns:
            continue
        
        try:
            # Baseline prediction
            baseline_pred = predict_model(model, data=country_data)['prediction_label'].values[0]
            
            # Intervention
            intervention_data = country_data.copy()
            new_val = intervention_data[variable].values[0] * (1 + pct_change)
            
            # Cap if percentage
            if any(x in variable.lower() for x in ['literacy', 'access', 'sanitation', 'water']):
                new_val = min(new_val, 100)
            
            intervention_data[variable] = new_val
            
            intervention_pred = predict_model(model, data=intervention_data)['prediction_label'].values[0]
            
            impact = baseline_pred - intervention_pred
            
            print(f"   {scenario_name}: {impact:+.3f} mortality reduction")
            
            report['policy_impacts'].append({
                'scenario': scenario_name,
                'variable': variable,
                'change': pct_change,
                'mortality_impact': impact
            })
            
        except Exception as e:
            print(f"   {scenario_name}: Error - {str(e)}")
    
    # Recommendation
    if report['policy_impacts']:
        best_policy = max(report['policy_impacts'], key=lambda x: x['mortality_impact'])
        
        print("\n" + "=" * 70)
        print(f"🏆 RECOMMENDED PRIORITY: {best_policy['scenario']}")
        print(f"   Expected mortality reduction: {best_policy['mortality_impact']:.3f} per 1,000")
        print("=" * 70)
        
        report['recommendation'] = best_policy
    
    return report


# =============================================================================
# MAIN EXECUTION (for testing)
# =============================================================================

if __name__ == "__main__":
    print("Testing policy simulation module...")
    
    if PYCARET_AVAILABLE:
        print("✅ PyCaret is available")
    else:
        print("⚠️ PyCaret not installed - predictions will not work")
    
    print("\nSee notebooks for complete usage examples.")
