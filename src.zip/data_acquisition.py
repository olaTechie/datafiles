"""
Data Acquisition Module
=======================

Robust data fetching from World Bank using wbgapi with comprehensive
variable definitions organised by the hierarchical determinants framework.

TEACHING NOTES:
--------------
1. The hierarchical framework (Distal → Intermediate → Proximate) reflects
   causal pathways in social epidemiology (Solar & Irwin, 2010).
   
2. We use `mrv=1` (most recent value) to maximise data completeness,
   but this means different countries may have data from different years.
   Discuss this limitation with students.

3. Aggregates (World, Regions) are removed to avoid ecological fallacy
   at the meta-level (analysing aggregates of aggregates).

Dependencies:
    pip install wbgapi pandas numpy
"""

import pandas as pd
import numpy as np
import wbgapi as wb
from typing import Dict, Tuple, Optional
import warnings

warnings.filterwarnings('ignore')


# =============================================================================
# VARIABLE DEFINITIONS (Hierarchical Framework)
# =============================================================================

def get_indicator_definitions() -> Dict[str, Dict[str, str]]:
    """
    Returns indicator definitions organised by the hierarchical
    determinants framework.
    
    TEACHING NOTE:
    -------------
    Draw this on the board as a DAG:
    
    DISTAL ──────► INTERMEDIATE ──────► PROXIMATE ──────► OUTCOME
    (root causes)   (systems)           (direct risks)    (mortality)
    
    Examples:
    - Education → Health literacy → Vaccination uptake → Child survival
    - Poverty → Poor sanitation → Diarrhoeal disease → Mortality
    
    Returns
    -------
    dict : Nested dictionary with indicator codes and friendly names
    """
    
    indicators = {
        'outcome': {
            'SP.DYN.CDRT.IN': 'crude_death_rate',
        },
        'context': {
            # Demographics - needed for funnel plots and weighting
            'SP.POP.TOTL': 'total_population',
            'SP.POP.65UP.TO.ZS': 'population_65_plus_pct',
        },
        'distal': {
            # Economic factors (root causes)
            'NY.GNP.PCAP.CD': 'gni_per_capita',
            'SI.POV.NAHC': 'poverty_headcount',
            'SI.POV.GINI': 'gini_index',
            'SH.XPD.CHEX.PC.CD': 'health_expenditure_pc',
            # Education
            'SE.ADT.LITR.FE.ZS': 'female_literacy',
            'SE.ADT.LITR.ZS': 'adult_literacy',
            'SE.XPD.TOTL.GD.ZS': 'education_expenditure_gdp',
        },
        'intermediate': {
            # Infrastructure & Systems
            'SH.H2O.SMDW.ZS': 'safe_water',
            'SH.STA.BASS.ZS': 'basic_sanitation',
            'EG.ELC.ACCS.ZS': 'electricity_access',
            # Health system capacity
            'SH.MED.BEDS.ZS': 'hospital_beds',
            'SH.MED.PHYS.ZS': 'physicians_density',
            'SH.MED.NUMW.P3': 'nurses_midwives_density',
            # Urbanisation
            'SP.URB.TOTL.IN.ZS': 'urban_population',
        },
        'proximate': {
            # Disease burden (direct causes)
            'SH.DTH.COMM.ZS': 'communicable_disease_deaths',
            'SH.DTH.NCOM.ZS': 'ncd_mortality_pct',
            'SH.DYN.AIDS.ZS': 'hiv_prevalence',
            # Preventive care
            'SH.IMM.MEAS': 'measles_immunisation',
            'SH.IMM.IDPT': 'dpt_immunisation',
            # Risk factors
            'SN.ITK.DEFC.ZS': 'undernourishment',
            'SH.PRV.SMOK': 'smoking_prevalence',
            'SH.STA.OWGH.ZS': 'overweight_prevalence',
        }
    }
    
    return indicators


def get_country_coordinates() -> pd.DataFrame:
    """
    Returns a DataFrame of country centroids for spatial analysis.
    
    TEACHING NOTE:
    -------------
    These are approximate centroids. For precise spatial analysis,
    you would use actual boundary shapefiles from Natural Earth
    or GADM databases.
    
    Returns
    -------
    pd.DataFrame : Country ISO codes with latitude and longitude
    """
    # Major countries with approximate centroids
    # In production, load from a proper geocoding service or shapefile
    coords = {
        'AFG': (33.0, 65.0), 'ALB': (41.0, 20.0), 'DZA': (28.0, 3.0),
        'AGO': (-12.5, 18.5), 'ARG': (-34.0, -64.0), 'ARM': (40.0, 45.0),
        'AUS': (-25.0, 135.0), 'AUT': (47.5, 14.5), 'AZE': (40.5, 47.5),
        'BGD': (24.0, 90.0), 'BLR': (53.0, 28.0), 'BEL': (50.5, 4.5),
        'BEN': (9.5, 2.25), 'BTN': (27.5, 90.5), 'BOL': (-17.0, -65.0),
        'BIH': (44.0, 18.0), 'BWA': (-22.0, 24.0), 'BRA': (-10.0, -55.0),
        'BGR': (43.0, 25.0), 'BFA': (13.0, -2.0), 'BDI': (-3.5, 30.0),
        'KHM': (13.0, 105.0), 'CMR': (6.0, 12.0), 'CAN': (60.0, -95.0),
        'CAF': (7.0, 21.0), 'TCD': (15.0, 19.0), 'CHL': (-30.0, -71.0),
        'CHN': (35.0, 105.0), 'COL': (4.0, -72.0), 'COD': (-3.0, 22.0),
        'COG': (-1.0, 15.0), 'CRI': (10.0, -84.0), 'CIV': (8.0, -5.0),
        'HRV': (45.0, 16.0), 'CUB': (22.0, -80.0), 'CYP': (35.0, 33.0),
        'CZE': (50.0, 15.5), 'DNK': (56.0, 10.0), 'DOM': (19.0, -70.5),
        'ECU': (-2.0, -77.5), 'EGY': (27.0, 30.0), 'SLV': (13.8, -88.9),
        'GNQ': (2.0, 10.0), 'ERI': (15.0, 39.0), 'EST': (59.0, 26.0),
        'SWZ': (-26.5, 31.5), 'ETH': (8.0, 38.0), 'FIN': (64.0, 26.0),
        'FRA': (46.0, 2.0), 'GAB': (-1.0, 11.5), 'GMB': (13.5, -16.5),
        'GEO': (42.0, 43.5), 'DEU': (51.0, 9.0), 'GHA': (8.0, -2.0),
        'GRC': (39.0, 22.0), 'GTM': (15.5, -90.25), 'GIN': (11.0, -10.0),
        'GNB': (12.0, -15.0), 'HTI': (19.0, -72.4), 'HND': (15.0, -86.5),
        'HUN': (47.0, 20.0), 'ISL': (65.0, -18.0), 'IND': (20.0, 77.0),
        'IDN': (-5.0, 120.0), 'IRN': (32.0, 53.0), 'IRQ': (33.0, 44.0),
        'IRL': (53.0, -8.0), 'ISR': (31.5, 35.0), 'ITA': (43.0, 12.0),
        'JAM': (18.25, -77.5), 'JPN': (36.0, 138.0), 'JOR': (31.0, 36.0),
        'KAZ': (48.0, 68.0), 'KEN': (1.0, 38.0), 'KOR': (37.0, 128.0),
        'KWT': (29.5, 47.75), 'KGZ': (41.0, 75.0), 'LAO': (18.0, 105.0),
        'LVA': (57.0, 25.0), 'LBN': (34.0, 36.0), 'LSO': (-29.5, 28.5),
        'LBR': (6.5, -9.5), 'LBY': (25.0, 17.0), 'LTU': (56.0, 24.0),
        'LUX': (49.75, 6.17), 'MDG': (-20.0, 47.0), 'MWI': (-13.5, 34.0),
        'MYS': (2.5, 112.5), 'MLI': (17.0, -4.0), 'MRT': (20.0, -12.0),
        'MUS': (-20.3, 57.5), 'MEX': (23.0, -102.0), 'MDA': (47.0, 29.0),
        'MNG': (46.0, 105.0), 'MNE': (42.5, 19.3), 'MAR': (32.0, -5.0),
        'MOZ': (-18.25, 35.0), 'MMR': (22.0, 98.0), 'NAM': (-22.0, 17.0),
        'NPL': (28.0, 84.0), 'NLD': (52.5, 5.75), 'NZL': (-42.0, 174.0),
        'NIC': (13.0, -85.0), 'NER': (16.0, 8.0), 'NGA': (10.0, 8.0),
        'MKD': (41.5, 22.0), 'NOR': (62.0, 10.0), 'OMN': (21.0, 57.0),
        'PAK': (30.0, 70.0), 'PAN': (9.0, -80.0), 'PNG': (-6.0, 147.0),
        'PRY': (-23.0, -58.0), 'PER': (-10.0, -76.0), 'PHL': (13.0, 122.0),
        'POL': (52.0, 20.0), 'PRT': (39.5, -8.0), 'QAT': (25.5, 51.25),
        'ROU': (46.0, 25.0), 'RUS': (60.0, 100.0), 'RWA': (-2.0, 30.0),
        'SAU': (25.0, 45.0), 'SEN': (14.0, -14.0), 'SRB': (44.0, 21.0),
        'SLE': (8.5, -11.5), 'SGP': (1.35, 103.8), 'SVK': (48.7, 19.5),
        'SVN': (46.0, 15.0), 'SOM': (5.0, 46.0), 'ZAF': (-29.0, 24.0),
        'SSD': (8.0, 30.0), 'ESP': (40.0, -4.0), 'LKA': (7.0, 81.0),
        'SDN': (15.0, 30.0), 'SUR': (4.0, -56.0), 'SWE': (62.0, 15.0),
        'CHE': (47.0, 8.0), 'SYR': (35.0, 38.0), 'TJK': (39.0, 71.0),
        'TZA': (-6.0, 35.0), 'THA': (15.0, 100.0), 'TLS': (-8.8, 126.0),
        'TGO': (8.0, 1.0), 'TTO': (10.5, -61.25), 'TUN': (34.0, 9.0),
        'TUR': (39.0, 35.0), 'TKM': (40.0, 60.0), 'UGA': (1.0, 32.0),
        'UKR': (49.0, 32.0), 'ARE': (24.0, 54.0), 'GBR': (54.0, -2.0),
        'USA': (38.0, -97.0), 'URY': (-33.0, -56.0), 'UZB': (41.0, 64.0),
        'VEN': (8.0, -66.0), 'VNM': (16.0, 108.0), 'YEM': (15.0, 48.0),
        'ZMB': (-15.0, 30.0), 'ZWE': (-20.0, 30.0),
    }
    
    df = pd.DataFrame([
        {'iso3_code': k, 'latitude': v[0], 'longitude': v[1]}
        for k, v in coords.items()
    ])
    
    return df


# =============================================================================
# DATA FETCHING FUNCTIONS
# =============================================================================

def fetch_world_bank_data(
    years: int = 1,
    verbose: bool = True
) -> Tuple[pd.DataFrame, Dict, Dict, Dict]:
    """
    Fetches and cleans World Bank data for ecological analysis.
    
    TEACHING NOTE:
    -------------
    This function demonstrates several important data science concepts:
    
    1. API-based data acquisition (reproducibility)
    2. Data cleaning and validation
    3. Handling missing data transparently
    4. Metadata enrichment (region, income group)
    
    Parameters
    ----------
    years : int
        Number of most recent values to fetch (default=1)
        Using mrv=1 maximises completeness but sacrifices temporal consistency
        
    verbose : bool
        Whether to print progress messages
        
    Returns
    -------
    tuple : (DataFrame, distal_dict, intermediate_dict, proximate_dict)
        - DataFrame with all indicators merged
        - Three dictionaries mapping codes to names for each level
    
    Example
    -------
    >>> df, distal, inter, prox = fetch_world_bank_data()
    >>> print(f"Loaded {len(df)} countries with {len(df.columns)} variables")
    """
    
    if verbose:
        print("🚀 Initialising Data Extraction Pipeline...")
        print("=" * 60)
    
    # Get indicator definitions
    indicators = get_indicator_definitions()
    
    # Flatten all indicators for fetching
    all_indicators = {}
    for category in indicators.values():
        all_indicators.update(category)
    
    # Fetch each indicator
    data_frames = []
    
    if verbose:
        print(f"\nDownloading {len(all_indicators)} indicators from World Bank...")
    
    for code, name in all_indicators.items():
        try:
            # mrv=1 gets most recent value for each country
            df = wb.data.DataFrame(code, mrv=years, labels=False)
            
            # Handle multi-year data
            if years > 1:
                # Take mean across years if multiple
                df = df.mean(axis=1).to_frame(name=name)
            else:
                df = df.rename(columns={code: name})
            
            data_frames.append(df)
            
            if verbose:
                non_null = df[name].notna().sum()
                print(f"  ✅ {name}: {non_null} countries")
                
        except Exception as e:
            if verbose:
                print(f"  ⚠️  Failed: {name} ({code}) - {str(e)[:50]}")
    
    if not data_frames:
        raise ValueError("No data downloaded! Check internet connection.")
    
    # Merge all dataframes
    if verbose:
        print("\n📊 Merging datasets...")
    
    df_merged = pd.concat(data_frames, axis=1)
    
    # Add country metadata
    economy_metadata = wb.economy.DataFrame()
    df_final = df_merged.join(
        economy_metadata[['name', 'region', 'incomeLevel', 'aggregate']]
    )
    
    # Remove aggregates (World, Regions, Income Groups)
    # CRITICAL: This prevents ecological fallacy at meta-level
    df_final = df_final[df_final['aggregate'] == False].copy()
    
    # Reset index and clean column names
    df_final = df_final.reset_index().rename(columns={
        'economy': 'iso3_code',
        'name': 'country',
        'incomeLevel': 'income_level'
    })
    
    # Add geographic coordinates for spatial analysis
    coords = get_country_coordinates()
    df_final = df_final.merge(coords, on='iso3_code', how='left')
    
    # Drop rows where outcome is missing (essential for modelling)
    initial_n = len(df_final)
    df_final = df_final.dropna(subset=['crude_death_rate'])
    
    if verbose:
        dropped = initial_n - len(df_final)
        print(f"  Dropped {dropped} countries with missing mortality data")
    
    # Reorder columns for clarity
    meta_cols = ['country', 'iso3_code', 'region', 'income_level', 
                 'latitude', 'longitude']
    data_cols = [c for c in df_final.columns 
                 if c not in meta_cols and c != 'aggregate']
    df_final = df_final[meta_cols + data_cols]
    
    # Drop the aggregate column
    if 'aggregate' in df_final.columns:
        df_final = df_final.drop(columns=['aggregate'])
    
    if verbose:
        print(f"\n🎉 Success! Final dataset:")
        print(f"   - {len(df_final)} countries")
        print(f"   - {len(data_cols)} variables")
        print(f"   - Regions: {df_final['region'].nunique()}")
        print("=" * 60)
    
    # Return data and dictionaries for each level
    return (
        df_final,
        indicators['distal'],
        indicators['intermediate'],
        indicators['proximate']
    )


def create_data_dictionary(df: pd.DataFrame) -> pd.DataFrame:
    """
    Creates a comprehensive data dictionary for the dataset.
    
    TEACHING NOTE:
    -------------
    A data dictionary is essential for:
    1. Reproducibility - others can understand your variables
    2. Quality control - spot missing data patterns
    3. Documentation - required for publications
    
    Parameters
    ----------
    df : pd.DataFrame
        The dataset to document
        
    Returns
    -------
    pd.DataFrame : Data dictionary with variable metadata
    
    Example
    -------
    >>> data_dict = create_data_dictionary(df)
    >>> data_dict.to_csv('data_dictionary.csv', index=False)
    """
    
    # Variable descriptions
    descriptions = {
        'country': 'Country name',
        'iso3_code': 'ISO 3166-1 alpha-3 country code',
        'region': 'World Bank geographic region',
        'income_level': 'World Bank income classification',
        'latitude': 'Country centroid latitude',
        'longitude': 'Country centroid longitude',
        'crude_death_rate': 'Deaths per 1,000 population per year',
        'total_population': 'Total population',
        'population_65_plus_pct': 'Percentage of population aged 65+',
        'gni_per_capita': 'Gross National Income per capita (current US$)',
        'poverty_headcount': 'Poverty headcount ratio at national poverty lines (%)',
        'gini_index': 'Gini index (0=perfect equality, 100=perfect inequality)',
        'health_expenditure_pc': 'Current health expenditure per capita (current US$)',
        'female_literacy': 'Female adult literacy rate (%)',
        'adult_literacy': 'Adult literacy rate, total (%)',
        'education_expenditure_gdp': 'Government expenditure on education (% of GDP)',
        'safe_water': 'People using safely managed drinking water services (%)',
        'basic_sanitation': 'People using at least basic sanitation services (%)',
        'electricity_access': 'Access to electricity (% of population)',
        'hospital_beds': 'Hospital beds per 1,000 people',
        'physicians_density': 'Physicians per 1,000 people',
        'nurses_midwives_density': 'Nurses and midwives per 1,000 people',
        'urban_population': 'Urban population (% of total population)',
        'communicable_disease_deaths': 'Cause of death by communicable diseases (%)',
        'ncd_mortality_pct': 'Cause of death by non-communicable diseases (%)',
        'hiv_prevalence': 'Prevalence of HIV (% of population ages 15-49)',
        'measles_immunisation': 'Measles immunisation coverage (%)',
        'dpt_immunisation': 'DPT immunisation coverage (%)',
        'undernourishment': 'Prevalence of undernourishment (%)',
        'smoking_prevalence': 'Smoking prevalence, total (%)',
        'overweight_prevalence': 'Prevalence of overweight (% of adults)',
    }
    
    # Determinant level
    levels = {
        'crude_death_rate': 'Outcome',
        'total_population': 'Context',
        'population_65_plus_pct': 'Context',
        'gni_per_capita': 'Distal',
        'poverty_headcount': 'Distal',
        'gini_index': 'Distal',
        'health_expenditure_pc': 'Distal',
        'female_literacy': 'Distal',
        'adult_literacy': 'Distal',
        'education_expenditure_gdp': 'Distal',
        'safe_water': 'Intermediate',
        'basic_sanitation': 'Intermediate',
        'electricity_access': 'Intermediate',
        'hospital_beds': 'Intermediate',
        'physicians_density': 'Intermediate',
        'nurses_midwives_density': 'Intermediate',
        'urban_population': 'Intermediate',
        'communicable_disease_deaths': 'Proximate',
        'ncd_mortality_pct': 'Proximate',
        'hiv_prevalence': 'Proximate',
        'measles_immunisation': 'Proximate',
        'dpt_immunisation': 'Proximate',
        'undernourishment': 'Proximate',
        'smoking_prevalence': 'Proximate',
        'overweight_prevalence': 'Proximate',
    }
    
    # Build dictionary
    records = []
    for col in df.columns:
        record = {
            'variable': col,
            'description': descriptions.get(col, 'No description available'),
            'determinant_level': levels.get(col, 'Metadata'),
            'dtype': str(df[col].dtype),
            'n_valid': df[col].notna().sum(),
            'n_missing': df[col].isna().sum(),
            'pct_missing': round(df[col].isna().sum() / len(df) * 100, 1),
            'n_unique': df[col].nunique(),
        }
        
        # Add summary stats for numeric columns
        if pd.api.types.is_numeric_dtype(df[col]):
            record.update({
                'min': round(df[col].min(), 2) if df[col].notna().any() else None,
                'max': round(df[col].max(), 2) if df[col].notna().any() else None,
                'mean': round(df[col].mean(), 2) if df[col].notna().any() else None,
                'median': round(df[col].median(), 2) if df[col].notna().any() else None,
                'std': round(df[col].std(), 2) if df[col].notna().any() else None,
            })
        else:
            record.update({
                'min': None, 'max': None, 'mean': None, 
                'median': None, 'std': None
            })
        
        records.append(record)
    
    return pd.DataFrame(records)


def analyze_missing_patterns(df: pd.DataFrame) -> pd.DataFrame:
    """
    Analyses missing data patterns to assess MCAR/MAR/MNAR assumptions.
    
    TEACHING NOTE:
    -------------
    Missing data mechanisms matter for inference:
    
    - MCAR (Missing Completely At Random): Safe to use complete cases
    - MAR (Missing At Random): Need multiple imputation
    - MNAR (Missing Not At Random): May need sensitivity analysis
    
    In World Bank data, missingness is often MAR - poor countries
    tend to have more missing health system data.
    
    Parameters
    ----------
    df : pd.DataFrame
        Dataset to analyse
        
    Returns
    -------
    pd.DataFrame : Missing data patterns by region and income
    """
    
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    
    # Calculate missingness by region
    region_missing = df.groupby('region')[numeric_cols].apply(
        lambda x: x.isna().mean() * 100
    ).round(1)
    
    # Calculate missingness by income level
    income_missing = df.groupby('income_level')[numeric_cols].apply(
        lambda x: x.isna().mean() * 100
    ).round(1)
    
    return region_missing, income_missing


# =============================================================================
# MAIN EXECUTION (for testing)
# =============================================================================

if __name__ == "__main__":
    # Test the module
    print("Testing data acquisition module...")
    df, distal, inter, prox = fetch_world_bank_data(verbose=True)
    
    print("\nData Dictionary Preview:")
    data_dict = create_data_dictionary(df)
    print(data_dict[['variable', 'determinant_level', 'n_valid', 'pct_missing']].head(15))
    
    print("\nMissing data by region:")
    reg_miss, inc_miss = analyze_missing_patterns(df)
    print(reg_miss.mean(axis=1).round(1))
