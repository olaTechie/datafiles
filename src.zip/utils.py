"""
Utility Functions Module
========================

Helper functions for data processing, validation, and export.

Contents:
- Data validation
- Missing data analysis
- Export functions
- Statistical helpers
"""

import pandas as pd
import numpy as np
from typing import List, Optional, Dict, Tuple
import warnings

warnings.filterwarnings('ignore')


# =============================================================================
# DATA VALIDATION
# =============================================================================

def validate_dataset(
    df: pd.DataFrame,
    required_columns: Optional[List[str]] = None,
    outcome: str = 'crude_death_rate'
) -> Dict:
    """
    Validates dataset completeness and quality.
    
    Parameters
    ----------
    df : pd.DataFrame
        Dataset to validate
    required_columns : list, optional
        Columns that must be present
    outcome : str
        Outcome variable name
        
    Returns
    -------
    dict : Validation results
    """
    
    results = {
        'is_valid': True,
        'errors': [],
        'warnings': [],
        'summary': {}
    }
    
    # Check if dataframe is empty
    if len(df) == 0:
        results['is_valid'] = False
        results['errors'].append("Dataset is empty")
        return results
    
    results['summary']['n_rows'] = len(df)
    results['summary']['n_cols'] = len(df.columns)
    
    # Check required columns
    if required_columns:
        missing_cols = [c for c in required_columns if c not in df.columns]
        if missing_cols:
            results['is_valid'] = False
            results['errors'].append(f"Missing required columns: {missing_cols}")
    
    # Check outcome variable
    if outcome not in df.columns:
        results['is_valid'] = False
        results['errors'].append(f"Outcome variable '{outcome}' not found")
    else:
        outcome_missing = df[outcome].isna().sum()
        results['summary']['outcome_missing'] = outcome_missing
        if outcome_missing > len(df) * 0.5:
            results['warnings'].append(f">50% of outcome values are missing")
    
    # Check for duplicates
    if 'iso3_code' in df.columns:
        duplicates = df['iso3_code'].duplicated().sum()
        if duplicates > 0:
            results['warnings'].append(f"{duplicates} duplicate country codes found")
    
    # Check numeric columns for validity
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    for col in numeric_cols:
        # Check for infinite values
        if np.isinf(df[col]).any():
            results['warnings'].append(f"Infinite values in '{col}'")
        
        # Check for negative values where inappropriate
        if any(x in col.lower() for x in ['rate', 'population', 'density', 'expenditure']):
            if (df[col] < 0).any():
                results['warnings'].append(f"Negative values in '{col}'")
    
    # Overall missing data
    total_missing = df.isna().sum().sum()
    total_cells = df.size
    results['summary']['pct_missing'] = round(total_missing / total_cells * 100, 1)
    
    if results['summary']['pct_missing'] > 30:
        results['warnings'].append(f"High overall missing data: {results['summary']['pct_missing']}%")
    
    # Print summary
    print("\n" + "=" * 60)
    print("📋 DATA VALIDATION REPORT")
    print("=" * 60)
    print(f"Rows: {results['summary']['n_rows']}")
    print(f"Columns: {results['summary']['n_cols']}")
    print(f"Overall missing: {results['summary']['pct_missing']}%")
    
    if results['errors']:
        print("\n❌ ERRORS:")
        for e in results['errors']:
            print(f"   - {e}")
    
    if results['warnings']:
        print("\n⚠️  WARNINGS:")
        for w in results['warnings']:
            print(f"   - {w}")
    
    if results['is_valid'] and not results['warnings']:
        print("\n✅ Dataset passed all validation checks")
    
    print("=" * 60)
    
    return results


def check_assumptions(
    df: pd.DataFrame,
    outcome: str = 'crude_death_rate'
) -> Dict:
    """
    Checks statistical assumptions for ecological regression.
    
    Returns
    -------
    dict : Assumption check results
    """
    
    results = {
        'sample_size': len(df),
        'adequate_sample': len(df) >= 30,
        'outcome_normality': None,
        'outcome_skewness': None,
        'potential_issues': []
    }
    
    if outcome in df.columns:
        outcome_data = df[outcome].dropna()
        
        # Test normality
        if len(outcome_data) >= 8:
            from scipy import stats
            stat, p = stats.shapiro(outcome_data[:5000])
            results['outcome_normality'] = p
            results['outcome_skewness'] = stats.skew(outcome_data)
            
            if results['outcome_skewness'] > 1:
                results['potential_issues'].append(
                    f"Outcome is right-skewed (skew={results['outcome_skewness']:.2f}). Consider log transformation."
                )
            elif results['outcome_skewness'] < -1:
                results['potential_issues'].append(
                    f"Outcome is left-skewed (skew={results['outcome_skewness']:.2f}). Consider transformation."
                )
    
    # Check for small sample issues
    if results['sample_size'] < 100:
        results['potential_issues'].append(
            f"Small sample (n={results['sample_size']}). Complex models may overfit."
        )
    
    return results


# =============================================================================
# MISSING DATA ANALYSIS
# =============================================================================

def analyze_missing_data(
    df: pd.DataFrame,
    by_group: Optional[str] = None
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Comprehensive missing data analysis.
    
    Parameters
    ----------
    df : pd.DataFrame
        Dataset
    by_group : str, optional
        Group variable for stratified analysis
        
    Returns
    -------
    tuple : (overall_missing_df, pattern_df)
    """
    
    # Overall missing by variable
    missing_summary = pd.DataFrame({
        'Variable': df.columns,
        'N_Missing': df.isna().sum().values,
        'Pct_Missing': (df.isna().sum() / len(df) * 100).round(1).values,
        'N_Valid': df.notna().sum().values
    }).sort_values('Pct_Missing', ascending=False)
    
    # Missing by group if specified
    if by_group and by_group in df.columns:
        group_missing = df.groupby(by_group).apply(
            lambda x: x.isna().mean() * 100
        ).round(1)
        
        print("\n📊 MISSING DATA BY GROUP:")
        print(group_missing.T)
    
    # Missing data patterns (simplified)
    numeric_cols = df.select_dtypes(include=[np.number]).columns[:10]  # Limit for readability
    pattern_df = df[numeric_cols].isna().astype(int)
    pattern_counts = pattern_df.groupby(list(numeric_cols)).size().reset_index(name='count')
    pattern_counts = pattern_counts.sort_values('count', ascending=False).head(10)
    
    print("\n📊 MISSING DATA SUMMARY:")
    print(missing_summary.head(15).to_string(index=False))
    
    return missing_summary, pattern_counts


# =============================================================================
# STATISTICAL HELPERS
# =============================================================================

def calculate_effect_size(
    r_squared: float,
    n: int,
    p: int
) -> Dict:
    """
    Calculates Cohen's f² effect size from R².
    
    Parameters
    ----------
    r_squared : float
        R-squared from regression
    n : int
        Sample size
    p : int
        Number of predictors
        
    Returns
    -------
    dict : Effect size measures
    """
    
    # Cohen's f²
    f_squared = r_squared / (1 - r_squared)
    
    # Classification
    if f_squared >= 0.35:
        interpretation = "Large"
    elif f_squared >= 0.15:
        interpretation = "Medium"
    elif f_squared >= 0.02:
        interpretation = "Small"
    else:
        interpretation = "Negligible"
    
    # Adjusted R²
    r_squared_adj = 1 - ((1 - r_squared) * (n - 1) / (n - p - 1))
    
    return {
        'r_squared': r_squared,
        'r_squared_adj': r_squared_adj,
        'cohens_f_squared': f_squared,
        'interpretation': interpretation
    }


def bootstrap_ci(
    data: np.ndarray,
    statistic: callable = np.mean,
    n_bootstrap: int = 1000,
    confidence_level: float = 0.95
) -> Tuple[float, float, float]:
    """
    Calculates bootstrap confidence interval for any statistic.
    
    Parameters
    ----------
    data : array-like
        Data to bootstrap
    statistic : callable
        Function to compute (default: mean)
    n_bootstrap : int
        Number of bootstrap samples
    confidence_level : float
        Confidence level
        
    Returns
    -------
    tuple : (point_estimate, ci_lower, ci_upper)
    """
    
    data = np.array(data)
    n = len(data)
    
    # Calculate bootstrap distribution
    bootstrap_stats = []
    for _ in range(n_bootstrap):
        sample = np.random.choice(data, size=n, replace=True)
        bootstrap_stats.append(statistic(sample))
    
    bootstrap_stats = np.array(bootstrap_stats)
    
    # Point estimate
    point = statistic(data)
    
    # Confidence interval (percentile method)
    alpha = 1 - confidence_level
    ci_lower = np.percentile(bootstrap_stats, alpha / 2 * 100)
    ci_upper = np.percentile(bootstrap_stats, (1 - alpha / 2) * 100)
    
    return point, ci_lower, ci_upper


# =============================================================================
# EXPORT FUNCTIONS
# =============================================================================

def export_results(
    results: Dict,
    filepath: str,
    format: str = 'xlsx'
) -> None:
    """
    Exports analysis results to file.
    
    Parameters
    ----------
    results : dict
        Dictionary of DataFrames and values to export
    filepath : str
        Output file path
    format : str
        'xlsx', 'csv', or 'json'
    """
    
    if format == 'xlsx':
        with pd.ExcelWriter(filepath) as writer:
            for name, data in results.items():
                if isinstance(data, pd.DataFrame):
                    data.to_excel(writer, sheet_name=name[:31], index=False)
                elif isinstance(data, dict):
                    pd.DataFrame([data]).to_excel(writer, sheet_name=name[:31], index=False)
        print(f"✅ Results exported to {filepath}")
        
    elif format == 'csv':
        for name, data in results.items():
            if isinstance(data, pd.DataFrame):
                data.to_csv(f"{filepath}_{name}.csv", index=False)
        print(f"✅ Results exported as CSV files")
        
    elif format == 'json':
        import json
        
        # Convert DataFrames to dicts
        export_data = {}
        for name, data in results.items():
            if isinstance(data, pd.DataFrame):
                export_data[name] = data.to_dict(orient='records')
            else:
                export_data[name] = data
        
        with open(filepath, 'w') as f:
            json.dump(export_data, f, indent=2, default=str)
        print(f"✅ Results exported to {filepath}")


def generate_report_template(
    df: pd.DataFrame,
    outcome: str = 'crude_death_rate'
) -> str:
    """
    Generates a template for writing up results.
    
    Returns
    -------
    str : Markdown template with placeholders
    """
    
    n_countries = len(df)
    n_regions = df['region'].nunique() if 'region' in df.columns else 'N/A'
    
    template = f"""
# Ecological Analysis of Global Mortality

## Methods

### Data Sources
We obtained data from the World Bank Open Data platform (https://data.worldbank.org) 
using the wbgapi Python library. Data represent the most recent available values 
for each indicator.

### Study Population
The analysis included **{n_countries} countries** across **{n_regions} regions**.
[LIST exclusion criteria if any]

### Variables

**Outcome:** {outcome.replace('_', ' ').title()}

**Distal Determinants:** [LIST]
**Intermediate Determinants:** [LIST]
**Proximate Determinants:** [LIST]

### Statistical Analysis

1. **Exploratory Analysis:** [Describe correlation analysis, clustering]

2. **Spatial Analysis:** Global Moran's I was calculated to test for spatial 
   autocorrelation. Local Indicators of Spatial Association (LISA) identified 
   hot spots and cold spots.

3. **Regression Analysis:** Progressive OLS models were built to examine 
   mediation pathways. Diagnostic tests included [VIF, Breusch-Pagan, etc.].
   [Note if robust standard errors were used]

4. **Machine Learning:** [Describe if used]

5. **Policy Simulation:** [Describe intervention scenarios]

## Results

### Descriptive Statistics
[INSERT Table 1]

### Spatial Patterns
Global Moran's I = [VALUE], p = [VALUE], indicating [INTERPRETATION].
LISA analysis identified [N] hot spots and [N] cold spots.

### Regression Results
[INSERT regression table]

The full model explained [XX]% of variance in mortality (Adjusted R² = [VALUE]).

### Policy Simulations
[INSERT policy comparison table]

## Discussion

### Key Findings
1. [Finding 1]
2. [Finding 2]
3. [Finding 3]

### Limitations
1. **Ecological Fallacy:** These findings describe country-level associations 
   and cannot be directly applied to individuals.
2. **Cross-sectional Design:** Cannot establish causation.
3. **Data Quality:** [Discuss missing data, measurement error]
4. **Unmeasured Confounding:** [Discuss potential confounders]

### Conclusions
[Summary and policy implications]

## References
[INSERT references]
"""
    
    return template


# =============================================================================
# MAIN EXECUTION
# =============================================================================

if __name__ == "__main__":
    print("Utility functions module loaded successfully.")
    print("\nAvailable functions:")
    print("  - validate_dataset()")
    print("  - check_assumptions()")
    print("  - analyze_missing_data()")
    print("  - calculate_effect_size()")
    print("  - bootstrap_ci()")
    print("  - export_results()")
    print("  - generate_report_template()")
