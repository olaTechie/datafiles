"""
Machine Learning Module
=======================

AutoML comparison using PyCaret with SHAP interpretation for
non-linear relationships in ecological data.

TEACHING NOTES:
--------------
1. WHY ML FOR ECOLOGICAL ANALYSIS?
   - Linear regression assumes linear relationships
   - GDP-mortality relationship is NON-LINEAR (diminishing returns)
   - Tree-based models capture thresholds and interactions automatically
   
2. ML VS. REGRESSION:
   - Regression: Interpretable coefficients, causal inference focus
   - ML: Better predictions, captures complexity, less interpretable
   - USE BOTH: ML for prediction, regression for inference

3. SHAP VALUES:
   - Model-agnostic interpretation method
   - Shows how each feature contributes to predictions
   - Positive SHAP = increases predicted mortality
   - Can reveal non-linear patterns that regression misses

4. ECOLOGICAL ML CAVEATS:
   - Small sample sizes (n ≈ 200) limit complex models
   - Overfitting risk is HIGH - always use cross-validation
   - Predictions are still ecological (country-level)

Key References:
- Lundberg, S.M. & Lee, S.I. (2017). A unified approach to interpreting
  model predictions. NeurIPS.
- Molnar, C. (2022). Interpretable Machine Learning.
- Breiman, L. (2001). Statistical modeling: The two cultures.

Dependencies:
    pip install pycaret shap pandas numpy matplotlib plotly
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from typing import Dict, List, Optional, Tuple, Any
import warnings

warnings.filterwarnings('ignore')

# Try to import PyCaret (may not be available in all environments)
try:
    from pycaret.regression import (
        setup, compare_models, create_model, tune_model,
        plot_model, evaluate_model, predict_model, get_config
    )
    PYCARET_AVAILABLE = True
except ImportError:
    PYCARET_AVAILABLE = False
    print("⚠️ PyCaret not available. Install with: pip install pycaret")

# Try to import SHAP
try:
    import shap
    SHAP_AVAILABLE = True
except ImportError:
    SHAP_AVAILABLE = False
    print("⚠️ SHAP not available. Install with: pip install shap")


# =============================================================================
# PYCARET SETUP AND MODEL COMPARISON
# =============================================================================

def setup_pycaret(
    df: pd.DataFrame,
    target: str = 'crude_death_rate',
    features: Optional[List[str]] = None,
    ignore_features: Optional[List[str]] = None,
    normalize: bool = True,
    remove_multicollinearity: bool = True,
    multicollinearity_threshold: float = 0.90,
    session_id: int = 42
) -> Any:
    """
    Initialises PyCaret environment for regression.
    
    TEACHING SCRIPT:
    ---------------
    "PyCaret automates the ML pipeline:
    
    1. DATA PREPROCESSING:
       - Normalisation (standardises features)
       - Missing value imputation
       - Multicollinearity removal (avoids redundant features)
    
    2. TRAIN-TEST SPLIT:
       - Automatically creates holdout set
       - Ensures fair model comparison
    
    3. CROSS-VALIDATION:
       - 10-fold CV by default
       - Robust performance estimates"
    
    Parameters
    ----------
    df : pd.DataFrame
        Dataset with target and features
    target : str
        Name of outcome variable
    features : list, optional
        Features to include (default: all numeric except target)
    ignore_features : list, optional
        Features to exclude (e.g., country names)
    normalize : bool
        Whether to standardise features
    remove_multicollinearity : bool
        Whether to remove highly correlated features
    multicollinearity_threshold : float
        Correlation threshold for removal
    session_id : int
        Random seed for reproducibility
        
    Returns
    -------
    pycaret experiment object
    """
    
    if not PYCARET_AVAILABLE:
        raise ImportError("PyCaret not installed. Run: pip install pycaret")
    
    print("\n" + "=" * 70)
    print("🤖 INITIALISING PYCARET ML ENVIRONMENT")
    print("=" * 70)
    
    # Prepare data
    if features is not None:
        cols_to_keep = [target] + features
        if ignore_features:
            cols_to_keep.extend(ignore_features)
        df_ml = df[cols_to_keep].copy()
    else:
        df_ml = df.copy()
    
    # Default ignore features
    if ignore_features is None:
        ignore_features = ['iso3_code', 'country', 'region', 'income_level',
                          'latitude', 'longitude']
    
    # Filter to existing columns
    ignore_features = [f for f in ignore_features if f in df_ml.columns]
    
    # Remove rows with missing target
    df_ml = df_ml.dropna(subset=[target])
    
    print(f"\nTarget variable: {target}")
    print(f"Observations: {len(df_ml)}")
    print(f"Features (before processing): {len(df_ml.columns) - len(ignore_features) - 1}")
    
    # Setup PyCaret
    exp = setup(
        data=df_ml,
        target=target,
        ignore_features=ignore_features,
        session_id=session_id,
        normalize=normalize,
        transformation=False,
        remove_multicollinearity=remove_multicollinearity,
        multicollinearity_threshold=multicollinearity_threshold,
        verbose=False,
        html=False
    )
    
    print("\n✅ PyCaret Environment Initialised")
    print("=" * 70)
    
    return exp


def compare_ml_models(
    n_select: int = 3,
    sort_by: str = 'R2',
    include: Optional[List[str]] = None
) -> Tuple[Any, pd.DataFrame]:
    """
    Compares multiple ML models using cross-validation.
    
    TEACHING SCRIPT:
    ---------------
    "PyCaret trains and evaluates multiple algorithms:
    
    - Linear Regression (baseline)
    - Ridge/Lasso (regularised linear)
    - Random Forest (ensemble of trees)
    - Gradient Boosting (sequential trees)
    - XGBoost/LightGBM (optimised boosting)
    
    Metrics to watch:
    - R²: Variance explained (higher is better)
    - RMSE: Prediction error (lower is better)
    - MAE: Average absolute error (lower is better)
    
    With small ecological samples (n ≈ 200):
    - Simpler models often perform best
    - Gradient boosting is often the winner on tabular data
    - Deep learning usually fails (not enough data)"
    
    Parameters
    ----------
    n_select : int
        Number of top models to return
    sort_by : str
        Metric to sort by ('R2', 'RMSE', 'MAE')
    include : list, optional
        Specific models to include
        
    Returns
    -------
    tuple : (best_model, comparison_dataframe)
    """
    
    if not PYCARET_AVAILABLE:
        raise ImportError("PyCaret not installed")
    
    print("\n" + "=" * 70)
    print("🏆 COMPARING ML MODELS")
    print("=" * 70)
    
    # Default models for small datasets
    if include is None:
        include = ['lr', 'ridge', 'lasso', 'en', 'rf', 'gbr', 'et', 'lightgbm']
    
    print("\nTraining models with 10-fold cross-validation...")
    print("This may take a few minutes...\n")
    
    # Compare models
    best_models = compare_models(
        sort=sort_by,
        n_select=n_select,
        include=include
    )
    
    # Get the best model (first in list if multiple)
    best_model = best_models[0] if isinstance(best_models, list) else best_models
    
    print(f"\n🥇 Best Model: {type(best_model).__name__}")
    print("=" * 70)
    
    return best_model, None


def create_and_tune_model(
    model_type: str = 'gbr',
    optimize: str = 'R2',
    n_iter: int = 10
) -> Any:
    """
    Creates and optionally tunes a specific model.
    
    TEACHING NOTE:
    -------------
    For small ecological datasets, extensive tuning often leads to
    overfitting. A few iterations is usually sufficient.
    
    Parameters
    ----------
    model_type : str
        Model abbreviation ('gbr', 'rf', 'ridge', etc.)
    optimize : str
        Metric to optimize
    n_iter : int
        Number of tuning iterations
        
    Returns
    -------
    Tuned model object
    """
    
    if not PYCARET_AVAILABLE:
        raise ImportError("PyCaret not installed")
    
    print(f"\n🔧 Creating {model_type.upper()} model...")
    
    # Create model
    model = create_model(model_type)
    
    # Tune if requested
    if n_iter > 0:
        print(f"   Tuning with {n_iter} iterations...")
        model = tune_model(model, optimize=optimize, n_iter=n_iter)
    
    return model


# =============================================================================
# MODEL INTERPRETATION
# =============================================================================

def interpret_model(
    model: Any,
    df: pd.DataFrame,
    target: str = 'crude_death_rate',
    max_display: int = 10
) -> Dict:
    """
    Interprets model using feature importance and SHAP values.
    
    TEACHING SCRIPT:
    ---------------
    "ML models are often called 'black boxes', but SHAP values
    help us understand what's driving predictions.
    
    SHAP (SHapley Additive exPlanations):
    - Based on game theory (fair allocation of contributions)
    - Shows each feature's impact on each prediction
    - Positive SHAP = increases predicted mortality
    - Negative SHAP = decreases predicted mortality
    
    The SUMMARY PLOT shows:
    - Feature importance (vertical position)
    - Feature effects (colour = feature value, x = SHAP value)
    - Non-linearities (when colour pattern isn't simple)"
    
    Parameters
    ----------
    model : Any
        Trained model
    df : pd.DataFrame
        Data for interpretation
    target : str
        Target variable name
    max_display : int
        Maximum features to show
        
    Returns
    -------
    dict : Interpretation results including SHAP values
    """
    
    results = {}
    
    print("\n" + "=" * 70)
    print("🔬 MODEL INTERPRETATION")
    print("=" * 70)
    
    # 1. Built-in feature importance (if available)
    if hasattr(model, 'feature_importances_'):
        print("\n1️⃣ FEATURE IMPORTANCE (Built-in)")
        print("-" * 50)
        
        # Get feature names from PyCaret config
        try:
            feature_names = get_config('X_train').columns.tolist()
        except:
            feature_names = [f'Feature_{i}' for i in range(len(model.feature_importances_))]
        
        importance_df = pd.DataFrame({
            'Feature': feature_names,
            'Importance': model.feature_importances_
        }).sort_values('Importance', ascending=False)
        
        results['feature_importance'] = importance_df
        
        print(importance_df.head(max_display).to_string(index=False))
        
        # Plot
        fig = px.bar(
            importance_df.head(max_display),
            x='Importance',
            y='Feature',
            orientation='h',
            title='<b>Feature Importance (Model Built-in)</b>'
        )
        fig.update_layout(yaxis={'categoryorder': 'total ascending'}, height=400)
        fig.show()
    
    # 2. SHAP values
    if SHAP_AVAILABLE:
        print("\n2️⃣ SHAP VALUES (Model-Agnostic)")
        print("-" * 50)
        
        try:
            # Get training data
            X_train = get_config('X_train')
            
            # Create SHAP explainer
            if hasattr(model, 'feature_importances_'):
                # Tree-based model
                explainer = shap.TreeExplainer(model)
            else:
                # Use KernelSHAP for other models (slower)
                explainer = shap.KernelExplainer(model.predict, X_train.sample(min(100, len(X_train))))
            
            # Calculate SHAP values
            shap_values = explainer.shap_values(X_train)
            
            results['shap_explainer'] = explainer
            results['shap_values'] = shap_values
            
            # Summary statistics
            mean_shap = np.abs(shap_values).mean(axis=0)
            shap_importance = pd.DataFrame({
                'Feature': X_train.columns,
                'Mean_|SHAP|': mean_shap
            }).sort_values('Mean_|SHAP|', ascending=False)
            
            results['shap_importance'] = shap_importance
            
            print("\nMean Absolute SHAP Values:")
            print(shap_importance.head(max_display).to_string(index=False))
            
            # Create SHAP summary plot
            print("\nGenerating SHAP summary plot...")
            plt.figure(figsize=(10, 8))
            shap.summary_plot(shap_values, X_train, max_display=max_display, show=False)
            plt.title('SHAP Summary Plot\n(Colour = Feature Value: Red=High, Blue=Low)')
            plt.tight_layout()
            plt.show()
            
            # SHAP bar plot
            plt.figure(figsize=(10, 6))
            shap.summary_plot(shap_values, X_train, plot_type='bar', 
                            max_display=max_display, show=False)
            plt.title('SHAP Feature Importance')
            plt.tight_layout()
            plt.show()
            
        except Exception as e:
            print(f"   ⚠️ SHAP calculation failed: {str(e)}")
            print("   This can happen with some model types or small datasets.")
    
    else:
        print("\n   ⚠️ SHAP not available. Install with: pip install shap")
    
    print("=" * 70)
    
    return results


def plot_partial_dependence(
    model: Any,
    feature: str,
    n_points: int = 50
) -> go.Figure:
    """
    Creates partial dependence plot for a single feature.
    
    TEACHING SCRIPT:
    ---------------
    "Partial dependence shows the AVERAGE effect of a feature
    on predictions, holding other features constant.
    
    For example, the GNI partial dependence plot might show:
    - Steep decrease in mortality at low GNI (strong effect)
    - Flat line at high GNI (diminishing returns)
    
    This reveals NON-LINEARITIES that regression would miss!"
    
    Parameters
    ----------
    model : Any
        Trained model
    feature : str
        Feature to plot
    n_points : int
        Number of points in the grid
        
    Returns
    -------
    go.Figure : Partial dependence plot
    """
    
    if not PYCARET_AVAILABLE:
        raise ImportError("PyCaret not installed")
    
    try:
        # Get training data
        X_train = get_config('X_train').copy()
        
        if feature not in X_train.columns:
            raise ValueError(f"Feature '{feature}' not found in training data")
        
        # Create grid of feature values
        feature_values = np.linspace(
            X_train[feature].min(),
            X_train[feature].max(),
            n_points
        )
        
        # Calculate partial dependence
        pd_values = []
        for val in feature_values:
            X_temp = X_train.copy()
            X_temp[feature] = val
            pred = model.predict(X_temp)
            pd_values.append(pred.mean())
        
        # Create plot
        fig = go.Figure()
        
        fig.add_trace(go.Scatter(
            x=feature_values,
            y=pd_values,
            mode='lines',
            line=dict(width=3, color='blue'),
            name='Partial Dependence'
        ))
        
        # Add rug plot (distribution of actual values)
        fig.add_trace(go.Scatter(
            x=X_train[feature],
            y=[min(pd_values)] * len(X_train),
            mode='markers',
            marker=dict(symbol='line-ns', size=10, color='grey', opacity=0.5),
            name='Data Distribution'
        ))
        
        fig.update_layout(
            title=f"<b>Partial Dependence Plot: {feature.replace('_', ' ').title()}</b>",
            xaxis_title=feature.replace('_', ' ').title(),
            yaxis_title='Predicted Crude Death Rate',
            height=450,
            showlegend=True
        )
        
        return fig
        
    except Exception as e:
        print(f"Error creating partial dependence plot: {e}")
        return None


# =============================================================================
# PREDICTION FUNCTIONS
# =============================================================================

def predict_mortality(
    model: Any,
    new_data: pd.DataFrame
) -> pd.DataFrame:
    """
    Makes predictions using trained model.
    
    Parameters
    ----------
    model : Any
        Trained model
    new_data : pd.DataFrame
        Data for prediction
        
    Returns
    -------
    pd.DataFrame : Data with predictions
    """
    
    if not PYCARET_AVAILABLE:
        raise ImportError("PyCaret not installed")
    
    predictions = predict_model(model, data=new_data)
    
    return predictions


def create_prediction_dashboard_data(
    model: Any,
    base_values: Dict[str, float],
    vary_feature: str,
    vary_range: Tuple[float, float],
    n_points: int = 50
) -> pd.DataFrame:
    """
    Creates data for interactive prediction exploration.
    
    Parameters
    ----------
    model : Any
        Trained model
    base_values : dict
        Base feature values
    vary_feature : str
        Feature to vary
    vary_range : tuple
        Range of values
    n_points : int
        Number of prediction points
        
    Returns
    -------
    pd.DataFrame : Feature values and predictions
    """
    
    feature_values = np.linspace(vary_range[0], vary_range[1], n_points)
    
    predictions = []
    for val in feature_values:
        input_data = base_values.copy()
        input_data[vary_feature] = val
        
        # Create dataframe for prediction
        input_df = pd.DataFrame([input_data])
        
        try:
            pred = predict_model(model, data=input_df)
            predictions.append(pred['prediction_label'].values[0])
        except:
            predictions.append(np.nan)
    
    result = pd.DataFrame({
        vary_feature: feature_values,
        'predicted_mortality': predictions
    })
    
    return result


# =============================================================================
# MAIN EXECUTION (for testing)
# =============================================================================

if __name__ == "__main__":
    print("Testing ML module...")
    
    if PYCARET_AVAILABLE:
        print("✅ PyCaret is available")
    else:
        print("⚠️ PyCaret not installed")
    
    if SHAP_AVAILABLE:
        print("✅ SHAP is available")
    else:
        print("⚠️ SHAP not installed")
    
    print("\nSee notebooks for complete usage examples.")
