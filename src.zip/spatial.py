"""
Spatial Analysis Module
=======================

Comprehensive spatial autocorrelation analysis including:
- Global Moran's I
- Local Indicators of Spatial Association (LISA)
- Hot spot / Cold spot detection (Getis-Ord Gi*)

TEACHING NOTES:
--------------
1. WHY SPATIAL ANALYSIS MATTERS:
   Countries are not independent observations. Neighbours share:
   - Trade relationships
   - Migration patterns
   - Cultural similarities
   - Disease transmission corridors
   
   Ignoring spatial autocorrelation leads to:
   - Underestimated standard errors
   - Inflated Type I error rates
   - Misleading significance tests

2. INTERPRETING MORAN'S I:
   - Positive I: Similar values cluster (high near high, low near low)
   - Negative I: Dissimilar values cluster (high near low)
   - I ≈ 0: Random spatial pattern
   
   Expected I under null = -1/(n-1) ≈ 0 for large n

3. LISA (Local Moran's I):
   Identifies WHERE clusters occur:
   - High-High: Hot spots (e.g., Sub-Saharan Africa mortality)
   - Low-Low: Cold spots (e.g., Western Europe mortality)
   - High-Low: Spatial outliers (high value surrounded by low)
   - Low-High: Spatial outliers (low value surrounded by high)

Key References:
- Anselin, L. (1995). Local indicators of spatial association—LISA.
- Cliff, A.D. & Ord, J.K. (1981). Spatial processes: Models & applications.
- Waller, L.A. & Gotway, C.A. (2004). Applied spatial statistics for public health.

Dependencies:
    pip install pandas numpy matplotlib seaborn plotly scipy
    pip install libpysal esda geopandas  # Optional but recommended
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from scipy.spatial.distance import cdist
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from typing import Dict, List, Optional, Tuple
import warnings

warnings.filterwarnings('ignore')


# =============================================================================
# SPATIAL WEIGHTS MATRIX
# =============================================================================

def create_spatial_weights(
    df: pd.DataFrame,
    method: str = 'knn',
    k: int = 5,
    threshold: float = None,
    lat_col: str = 'latitude',
    lon_col: str = 'longitude',
    row_standardize: bool = True
) -> Tuple[np.ndarray, List[str]]:
    """
    Creates a spatial weights matrix for countries.
    
    TEACHING SCRIPT:
    ---------------
    "Before we can test for spatial autocorrelation, we need to define
    what 'neighbours' means. There are several approaches:
    
    1. K-NEAREST NEIGHBOURS (KNN): Each country has exactly k neighbours
       - Pro: Every country has neighbours (even islands)
       - Con: 'Neighbourhood' varies in geographic size
    
    2. DISTANCE THRESHOLD: Neighbours within d kilometres
       - Pro: Consistent geographic definition
       - Con: Some countries may have no neighbours (islands)
    
    3. CONTIGUITY: Share a border
       - Pro: Natural definition for land neighbours
       - Con: Excludes islands, excludes across-ocean relationships
    
    For this workshop, we use KNN with k=5 as a robust default."
    
    Parameters
    ----------
    df : pd.DataFrame
        Data with latitude and longitude columns
    method : str
        'knn' (k-nearest neighbours) or 'distance' (threshold)
    k : int
        Number of neighbours for KNN
    threshold : float
        Distance threshold in degrees (for distance method)
    lat_col, lon_col : str
        Column names for coordinates
    row_standardize : bool
        Whether to row-standardize weights (sum to 1)
        
    Returns
    -------
    tuple : (weights_matrix, list of country IDs in order)
    """
    
    # Check for required columns
    if lat_col not in df.columns or lon_col not in df.columns:
        raise ValueError(f"Need {lat_col} and {lon_col} columns")
    
    # Remove rows with missing coordinates
    df_spatial = df.dropna(subset=[lat_col, lon_col]).copy()
    
    if len(df_spatial) < k + 1:
        raise ValueError(f"Need at least {k+1} observations for KNN with k={k}")
    
    # Extract coordinates
    coords = df_spatial[[lat_col, lon_col]].values
    n = len(coords)
    
    # Calculate distance matrix (Euclidean on lat/lon - approximate)
    # For more accuracy, use Haversine distance
    dist_matrix = cdist(coords, coords, metric='euclidean')
    
    # Create weights matrix
    W = np.zeros((n, n))
    
    if method == 'knn':
        # K-nearest neighbours
        for i in range(n):
            # Get indices of k nearest (excluding self)
            distances = dist_matrix[i, :]
            # Set self-distance to infinity
            distances_copy = distances.copy()
            distances_copy[i] = np.inf
            # Find k smallest
            nearest_idx = np.argsort(distances_copy)[:k]
            W[i, nearest_idx] = 1
            
    elif method == 'distance':
        if threshold is None:
            # Default: use median nearest-neighbour distance * 2
            nn_distances = []
            for i in range(n):
                distances = dist_matrix[i, :]
                distances_sorted = np.sort(distances)
                nn_distances.append(distances_sorted[1])  # First non-self
            threshold = np.median(nn_distances) * 2
            print(f"Using threshold = {threshold:.2f} degrees")
        
        W = (dist_matrix < threshold) & (dist_matrix > 0)
        W = W.astype(float)
    
    else:
        raise ValueError(f"Unknown method: {method}")
    
    # Row standardize if requested
    if row_standardize:
        row_sums = W.sum(axis=1, keepdims=True)
        row_sums[row_sums == 0] = 1  # Avoid division by zero
        W = W / row_sums
    
    # Get country identifiers
    if 'iso3_code' in df_spatial.columns:
        ids = df_spatial['iso3_code'].tolist()
    elif 'country' in df_spatial.columns:
        ids = df_spatial['country'].tolist()
    else:
        ids = df_spatial.index.tolist()
    
    print(f"\n📊 SPATIAL WEIGHTS SUMMARY")
    print("=" * 50)
    print(f"Method: {method.upper()}")
    if method == 'knn':
        print(f"K neighbours: {k}")
    else:
        print(f"Distance threshold: {threshold:.2f}")
    print(f"Countries included: {n}")
    print(f"Average neighbours per country: {W.sum() / n:.1f}")
    print(f"Row standardized: {row_standardize}")
    print("=" * 50)
    
    return W, ids, df_spatial


# =============================================================================
# GLOBAL MORAN'S I
# =============================================================================

def calculate_moran_i(
    df: pd.DataFrame,
    variable: str,
    W: np.ndarray,
    ids: List[str],
    n_permutations: int = 999
) -> Dict:
    """
    Calculates Global Moran's I statistic with inference.
    
    TEACHING SCRIPT:
    ---------------
    "Moran's I is the spatial equivalent of a correlation coefficient.
    
    Formula: I = (n/S₀) * Σᵢ Σⱼ wᵢⱼ(xᵢ - x̄)(xⱼ - x̄) / Σᵢ(xᵢ - x̄)²
    
    Where:
    - n = number of observations
    - wᵢⱼ = spatial weight between i and j
    - S₀ = sum of all weights
    - xᵢ, xⱼ = values for locations i and j
    - x̄ = mean value
    
    Interpretation:
    - I > 0: Positive spatial autocorrelation (clustering of similar values)
    - I < 0: Negative spatial autocorrelation (dispersed pattern)
    - I ≈ -1/(n-1): Random pattern
    
    We use permutation inference because:
    1. Distribution of I is complex
    2. Permutation tests are non-parametric
    3. Easy to interpret: 'In X% of random permutations, I was this extreme'"
    
    Parameters
    ----------
    df : pd.DataFrame
        Data with the variable to test
    variable : str
        Column name of variable
    W : np.ndarray
        Spatial weights matrix
    ids : list
        Country IDs corresponding to W rows
    n_permutations : int
        Number of permutations for inference
        
    Returns
    -------
    dict : Moran's I results including statistic, p-value, interpretation
    """
    
    # Align data with weights matrix order
    if 'iso3_code' in df.columns:
        df_aligned = df.set_index('iso3_code').loc[ids]
    elif 'country' in df.columns:
        df_aligned = df.set_index('country').loc[ids]
    else:
        df_aligned = df.loc[ids]
    
    # Extract values
    y = df_aligned[variable].values
    
    # Handle missing values
    valid_mask = ~np.isnan(y)
    if not all(valid_mask):
        print(f"Warning: {sum(~valid_mask)} missing values removed")
        y = y[valid_mask]
        W_sub = W[np.ix_(valid_mask, valid_mask)]
        # Re-normalize weights
        row_sums = W_sub.sum(axis=1, keepdims=True)
        row_sums[row_sums == 0] = 1
        W_sub = W_sub / row_sums
    else:
        W_sub = W
    
    n = len(y)
    
    # Calculate Moran's I
    def moran_i_stat(values, weights):
        """Calculate Moran's I for given values and weights"""
        y_dev = values - values.mean()
        numerator = np.sum(weights * np.outer(y_dev, y_dev))
        denominator = np.sum(y_dev ** 2)
        S0 = weights.sum()
        I = (n / S0) * (numerator / denominator) if denominator > 0 else 0
        return I
    
    # Observed Moran's I
    I_observed = moran_i_stat(y, W_sub)
    
    # Expected value under null
    I_expected = -1 / (n - 1)
    
    # Permutation inference
    I_permuted = []
    for _ in range(n_permutations):
        y_perm = np.random.permutation(y)
        I_permuted.append(moran_i_stat(y_perm, W_sub))
    
    I_permuted = np.array(I_permuted)
    
    # Calculate p-value (two-tailed)
    p_value = (np.sum(np.abs(I_permuted) >= np.abs(I_observed)) + 1) / (n_permutations + 1)
    
    # Z-score
    z_score = (I_observed - np.mean(I_permuted)) / np.std(I_permuted)
    
    # Interpretation
    if p_value < 0.05:
        if I_observed > I_expected:
            interpretation = "SIGNIFICANT POSITIVE spatial autocorrelation (clustering)"
        else:
            interpretation = "SIGNIFICANT NEGATIVE spatial autocorrelation (dispersion)"
    else:
        interpretation = "No significant spatial autocorrelation (random pattern)"
    
    results = {
        'variable': variable,
        'moran_i': I_observed,
        'expected_i': I_expected,
        'z_score': z_score,
        'p_value': p_value,
        'n_observations': n,
        'n_permutations': n_permutations,
        'interpretation': interpretation,
        'permuted_values': I_permuted
    }
    
    # Print results
    print("\n" + "=" * 60)
    print(f"🌍 GLOBAL MORAN'S I TEST: {variable}")
    print("=" * 60)
    print(f"Moran's I:     {I_observed:.4f}")
    print(f"Expected I:    {I_expected:.4f}")
    print(f"Z-score:       {z_score:.4f}")
    print(f"P-value:       {p_value:.4f}")
    print(f"\n{interpretation}")
    if p_value < 0.05:
        print("\n⚠️  IMPLICATION: Standard regression may have inflated Type I errors!")
        print("   Consider: Spatial lag models, spatial error models, or robust SEs")
    print("=" * 60)
    
    return results


def plot_moran_scatterplot(
    df: pd.DataFrame,
    variable: str,
    W: np.ndarray,
    ids: List[str],
    moran_results: Dict = None
) -> go.Figure:
    """
    Creates a Moran scatter plot (value vs. spatial lag).
    
    TEACHING SCRIPT:
    ---------------
    "The Moran scatter plot shows each observation's value (x-axis)
    against its SPATIAL LAG (y-axis) - the weighted average of neighbours.
    
    The four quadrants represent:
    - HH (top-right): High values surrounded by high → Hot spot
    - LL (bottom-left): Low values surrounded by low → Cold spot
    - HL (bottom-right): High values surrounded by low → Spatial outlier
    - LH (top-left): Low values surrounded by high → Spatial outlier
    
    The slope of the best-fit line approximates Moran's I."
    
    Parameters
    ----------
    df : pd.DataFrame
        Data
    variable : str
        Variable to plot
    W : np.ndarray
        Spatial weights matrix
    ids : list
        Country IDs
    moran_results : dict, optional
        Results from calculate_moran_i (for annotation)
        
    Returns
    -------
    go.Figure : Interactive Moran scatter plot
    """
    
    # Align data
    if 'iso3_code' in df.columns:
        df_aligned = df.set_index('iso3_code').loc[ids].reset_index()
        id_col = 'iso3_code'
    elif 'country' in df.columns:
        df_aligned = df.set_index('country').loc[ids].reset_index()
        id_col = 'country'
    else:
        df_aligned = df.loc[ids].reset_index()
        id_col = 'index'
    
    # Extract and standardize values
    y = df_aligned[variable].values
    valid_mask = ~np.isnan(y)
    y_valid = y[valid_mask]
    
    # Standardize
    y_std = (y_valid - np.mean(y_valid)) / np.std(y_valid)
    
    # Calculate spatial lag
    W_valid = W[np.ix_(valid_mask, valid_mask)]
    row_sums = W_valid.sum(axis=1, keepdims=True)
    row_sums[row_sums == 0] = 1
    W_valid = W_valid / row_sums
    
    spatial_lag = W_valid @ y_std
    
    # Determine quadrants
    quadrants = []
    for x, lag in zip(y_std, spatial_lag):
        if x >= 0 and lag >= 0:
            quadrants.append('HH (Hot Spot)')
        elif x < 0 and lag < 0:
            quadrants.append('LL (Cold Spot)')
        elif x >= 0 and lag < 0:
            quadrants.append('HL (Outlier)')
        else:
            quadrants.append('LH (Outlier)')
    
    # Get country names for valid observations
    countries_valid = df_aligned.loc[valid_mask, id_col].values if id_col in df_aligned.columns else None
    
    # Create plot
    colors = {
        'HH (Hot Spot)': '#e74c3c',
        'LL (Cold Spot)': '#3498db',
        'HL (Outlier)': '#f39c12',
        'LH (Outlier)': '#9b59b6'
    }
    
    fig = go.Figure()
    
    # Add points by quadrant
    for quad in ['HH (Hot Spot)', 'LL (Cold Spot)', 'HL (Outlier)', 'LH (Outlier)']:
        mask = np.array(quadrants) == quad
        fig.add_trace(go.Scatter(
            x=y_std[mask],
            y=spatial_lag[mask],
            mode='markers',
            name=quad,
            marker=dict(size=10, color=colors[quad], opacity=0.7),
            text=countries_valid[mask] if countries_valid is not None else None,
            hovertemplate='%{text}<br>Value (std): %{x:.2f}<br>Spatial Lag: %{y:.2f}'
        ))
    
    # Add quadrant lines
    fig.add_hline(y=0, line_dash='dash', line_color='gray')
    fig.add_vline(x=0, line_dash='dash', line_color='gray')
    
    # Add regression line (slope = Moran's I)
    slope, intercept = np.polyfit(y_std, spatial_lag, 1)
    x_line = np.linspace(y_std.min(), y_std.max(), 100)
    fig.add_trace(go.Scatter(
        x=x_line,
        y=slope * x_line + intercept,
        mode='lines',
        name=f"Moran's I ≈ {slope:.3f}",
        line=dict(color='black', width=2)
    ))
    
    # Add quadrant labels
    annotations = [
        dict(x=2, y=2, text='<b>HH</b><br>Hot Spots', showarrow=False, font=dict(color='#e74c3c', size=14)),
        dict(x=-2, y=-2, text='<b>LL</b><br>Cold Spots', showarrow=False, font=dict(color='#3498db', size=14)),
        dict(x=2, y=-2, text='<b>HL</b><br>Outliers', showarrow=False, font=dict(color='#f39c12', size=14)),
        dict(x=-2, y=2, text='<b>LH</b><br>Outliers', showarrow=False, font=dict(color='#9b59b6', size=14)),
    ]
    
    title = f"<b>Moran Scatter Plot: {variable.replace('_', ' ').title()}</b>"
    if moran_results:
        title += f"<br><span style='font-size:12px'>I = {moran_results['moran_i']:.3f}, p = {moran_results['p_value']:.3f}</span>"
    
    fig.update_layout(
        title=title,
        xaxis_title=f'{variable} (standardised)',
        yaxis_title='Spatial Lag (neighbour average)',
        annotations=annotations,
        height=600,
        showlegend=True
    )
    
    return fig


# =============================================================================
# LOCAL INDICATORS OF SPATIAL ASSOCIATION (LISA)
# =============================================================================

def calculate_lisa(
    df: pd.DataFrame,
    variable: str,
    W: np.ndarray,
    ids: List[str],
    n_permutations: int = 999,
    significance_level: float = 0.05
) -> pd.DataFrame:
    """
    Calculates Local Moran's I (LISA) for each observation.
    
    TEACHING SCRIPT:
    ---------------
    "While Global Moran's I tells us WHETHER there's clustering,
    LISA tells us WHERE the clusters are.
    
    Each location gets:
    1. A local I statistic (contribution to global pattern)
    2. A p-value (is this location significant?)
    3. A quadrant classification (HH, LL, HL, LH)
    
    LISA is essential for:
    - Identifying disease hot spots
    - Finding unusual countries (spatial outliers)
    - Targeting interventions geographically"
    
    Parameters
    ----------
    df : pd.DataFrame
        Data
    variable : str
        Variable to analyze
    W : np.ndarray
        Spatial weights matrix
    ids : list
        Country IDs
    n_permutations : int
        Permutations for inference
    significance_level : float
        Threshold for significance
        
    Returns
    -------
    pd.DataFrame : LISA results for each location
    """
    
    # Align data
    if 'iso3_code' in df.columns:
        df_aligned = df.set_index('iso3_code').loc[ids].reset_index()
        id_col = 'iso3_code'
    else:
        df_aligned = df.loc[ids].reset_index()
        id_col = 'index'
    
    y = df_aligned[variable].values
    valid_mask = ~np.isnan(y)
    n = sum(valid_mask)
    
    y_valid = y[valid_mask]
    W_valid = W[np.ix_(valid_mask, valid_mask)]
    ids_valid = [ids[i] for i, v in enumerate(valid_mask) if v]
    
    # Standardize
    y_std = (y_valid - np.mean(y_valid)) / np.std(y_valid)
    
    # Calculate local Moran's I for each observation
    local_i = np.zeros(n)
    spatial_lags = np.zeros(n)
    
    for i in range(n):
        # Local I = z_i * sum(w_ij * z_j)
        spatial_lags[i] = np.sum(W_valid[i, :] * y_std)
        local_i[i] = y_std[i] * spatial_lags[i]
    
    # Permutation inference for each location
    p_values = np.zeros(n)
    
    for i in range(n):
        # Permute other locations' values
        other_indices = np.arange(n) != i
        
        local_i_perm = []
        for _ in range(n_permutations):
            y_perm = y_std.copy()
            y_perm[other_indices] = np.random.permutation(y_std[other_indices])
            lag_perm = np.sum(W_valid[i, :] * y_perm)
            local_i_perm.append(y_std[i] * lag_perm)
        
        # Two-tailed p-value
        p_values[i] = (np.sum(np.abs(local_i_perm) >= np.abs(local_i[i])) + 1) / (n_permutations + 1)
    
    # Classify quadrants
    quadrants = []
    for z, lag in zip(y_std, spatial_lags):
        if z >= 0 and lag >= 0:
            quadrants.append('HH')
        elif z < 0 and lag < 0:
            quadrants.append('LL')
        elif z >= 0 and lag < 0:
            quadrants.append('HL')
        else:
            quadrants.append('LH')
    
    # Significant classification
    significant_cluster = []
    for q, p in zip(quadrants, p_values):
        if p < significance_level:
            significant_cluster.append(q)
        else:
            significant_cluster.append('Not Significant')
    
    # Build results DataFrame
    results = pd.DataFrame({
        'id': ids_valid,
        'value': y_valid,
        'value_std': y_std,
        'spatial_lag': spatial_lags,
        'local_i': local_i,
        'p_value': p_values,
        'quadrant': quadrants,
        'cluster_type': significant_cluster
    })
    
    # Merge with original data for country names
    if 'country' in df_aligned.columns and id_col != 'country':
        country_map = dict(zip(df_aligned[id_col], df_aligned['country']))
        results['country'] = results['id'].map(country_map)
    
    # Print summary
    print("\n" + "=" * 60)
    print(f"🗺️  LISA ANALYSIS: {variable}")
    print("=" * 60)
    print(f"\nSignificant clusters (p < {significance_level}):")
    print(results['cluster_type'].value_counts())
    
    sig_results = results[results['cluster_type'] != 'Not Significant']
    if len(sig_results) > 0:
        print("\n📍 HOT SPOTS (HH):")
        hh = sig_results[sig_results['cluster_type'] == 'HH']
        if 'country' in hh.columns:
            print(f"   {', '.join(hh['country'].head(10).tolist())}")
        
        print("\n❄️  COLD SPOTS (LL):")
        ll = sig_results[sig_results['cluster_type'] == 'LL']
        if 'country' in ll.columns:
            print(f"   {', '.join(ll['country'].head(10).tolist())}")
    
    print("=" * 60)
    
    return results


def plot_lisa_map(
    df: pd.DataFrame,
    lisa_results: pd.DataFrame,
    variable: str
) -> go.Figure:
    """
    Creates a choropleth map showing LISA cluster types.
    
    Parameters
    ----------
    df : pd.DataFrame
        Original data with ISO codes
    lisa_results : pd.DataFrame
        Results from calculate_lisa
    variable : str
        Variable name for title
        
    Returns
    -------
    go.Figure : LISA cluster map
    """
    
    # Merge LISA results with geographic data
    if 'iso3_code' in df.columns:
        df_plot = df.merge(lisa_results, left_on='iso3_code', right_on='id', how='left')
    else:
        df_plot = df.merge(lisa_results, left_index=True, right_on='id', how='left')
    
    # Color mapping
    color_map = {
        'HH': '#e74c3c',      # Red - Hot spots
        'LL': '#3498db',      # Blue - Cold spots
        'HL': '#f39c12',      # Orange - High outlier
        'LH': '#9b59b6',      # Purple - Low outlier
        'Not Significant': '#bdc3c7'  # Grey
    }
    
    df_plot['color'] = df_plot['cluster_type'].map(color_map)
    df_plot['color'] = df_plot['color'].fillna('#bdc3c7')
    
    fig = px.choropleth(
        df_plot,
        locations='iso3_code',
        color='cluster_type',
        color_discrete_map=color_map,
        hover_name='country' if 'country' in df_plot.columns else 'iso3_code',
        hover_data=['value', 'local_i', 'p_value'] if 'local_i' in df_plot.columns else None,
        title=f"<b>LISA Cluster Map: {variable.replace('_', ' ').title()}</b>",
        projection='natural earth'
    )
    
    fig.update_layout(
        height=600,
        geo=dict(
            showframe=False,
            showcoastlines=True,
            coastlinecolor='gray'
        ),
        legend_title_text='Cluster Type'
    )
    
    return fig


def plot_hotspot_map(
    df: pd.DataFrame,
    variable: str,
    W: np.ndarray,
    ids: List[str],
    lisa_results: pd.DataFrame = None
) -> go.Figure:
    """
    Creates a hot spot / cold spot map using bubble sizes for emphasis.
    
    TEACHING SCRIPT:
    ---------------
    "This map combines two pieces of information:
    
    1. COLOUR: The cluster type
       - Red = Hot spot (high values clustered)
       - Blue = Cold spot (low values clustered)
    
    2. SIZE: The statistical significance
       - Larger bubbles = more significant (lower p-value)
       - This helps identify the MOST reliable clusters
    
    For mortality, red hot spots are areas where intervention
    is most needed - high mortality surrounded by high mortality."
    
    Parameters
    ----------
    df : pd.DataFrame
        Original data
    variable : str
        Variable being mapped
    W : np.ndarray
        Spatial weights
    ids : list
        Country IDs
    lisa_results : pd.DataFrame, optional
        Pre-calculated LISA results
        
    Returns
    -------
    go.Figure : Hot spot map with bubbles
    """
    
    # Calculate LISA if not provided
    if lisa_results is None:
        lisa_results = calculate_lisa(df, variable, W, ids)
    
    # Merge with original data
    if 'iso3_code' in df.columns:
        df_plot = df.merge(lisa_results, left_on='iso3_code', right_on='id', how='inner')
    else:
        df_plot = df.merge(lisa_results, left_index=True, right_on='id', how='inner')
    
    # Filter to significant results
    df_sig = df_plot[df_plot['cluster_type'] != 'Not Significant'].copy()
    
    # Size by significance (inverse of p-value, scaled)
    df_sig['bubble_size'] = 50 / (df_sig['p_value'] + 0.01)
    df_sig['bubble_size'] = df_sig['bubble_size'].clip(upper=100)
    
    # Color mapping
    color_map = {
        'HH': '#e74c3c',
        'LL': '#3498db',
        'HL': '#f39c12',
        'LH': '#9b59b6'
    }
    
    fig = go.Figure()
    
    # Add base map (all countries in grey)
    fig.add_trace(go.Choropleth(
        locations=df['iso3_code'] if 'iso3_code' in df.columns else df.index,
        z=[1] * len(df),
        colorscale=[[0, '#ecf0f1'], [1, '#ecf0f1']],
        showscale=False,
        hoverinfo='skip'
    ))
    
    # Add bubbles for significant clusters
    for cluster_type in ['HH', 'LL', 'HL', 'LH']:
        df_cluster = df_sig[df_sig['cluster_type'] == cluster_type]
        if len(df_cluster) == 0:
            continue
        
        # Get coordinates
        if 'latitude' in df_cluster.columns and 'longitude' in df_cluster.columns:
            lat_col, lon_col = 'latitude', 'longitude'
        else:
            continue
        
        fig.add_trace(go.Scattergeo(
            lat=df_cluster[lat_col],
            lon=df_cluster[lon_col],
            mode='markers',
            marker=dict(
                size=df_cluster['bubble_size'],
                color=color_map[cluster_type],
                opacity=0.7,
                line=dict(width=1, color='white')
            ),
            name=f"{cluster_type} ({'Hot Spot' if cluster_type == 'HH' else 'Cold Spot' if cluster_type == 'LL' else 'Outlier'})",
            text=df_cluster['country'] if 'country' in df_cluster.columns else df_cluster['id'],
            hovertemplate='%{text}<br>Type: ' + cluster_type + '<br>p-value: %{customdata:.3f}',
            customdata=df_cluster['p_value']
        ))
    
    fig.update_layout(
        title=f"<b>Hot Spot Analysis: {variable.replace('_', ' ').title()}</b><br>" +
              "<span style='font-size:12px'>Bubble size indicates statistical significance</span>",
        geo=dict(
            showframe=False,
            showcoastlines=True,
            coastlinecolor='gray',
            projection_type='natural earth'
        ),
        height=600,
        showlegend=True
    )
    
    return fig


# =============================================================================
# MAIN EXECUTION (for testing)
# =============================================================================

if __name__ == "__main__":
    print("Testing spatial analysis module...")
    print("\nThis module requires data with coordinates.")
    print("See notebooks for complete usage examples.")
    
    # Quick synthetic test
    np.random.seed(42)
    n = 50
    test_df = pd.DataFrame({
        'country': [f'Country_{i}' for i in range(n)],
        'iso3_code': [f'C{i:02d}' for i in range(n)],
        'latitude': np.random.uniform(-50, 50, n),
        'longitude': np.random.uniform(-100, 100, n),
        'test_var': np.random.normal(10, 2, n)
    })
    
    print("\nCreating spatial weights...")
    W, ids, df_spatial = create_spatial_weights(test_df, k=5)
    
    print("\nCalculating Moran's I...")
    results = calculate_moran_i(test_df, 'test_var', W, ids, n_permutations=99)
