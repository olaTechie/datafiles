"""
Interactive Dashboard Module
============================

Gradio-based interactive teaching dashboard for live demonstrations.

TEACHING NOTES:
--------------
This dashboard enables live "what-if" exploration during workshops:
- Students adjust sliders and see immediate predictions
- Facilitates discussion about determinant importance
- Demonstrates model extrapolation issues

Launch with: python -m src.dashboard
Or from notebook: from src.dashboard import launch_dashboard

Dependencies:
    pip install gradio pandas numpy
"""

import pandas as pd
import numpy as np
from typing import Any, Optional, Dict
import warnings

warnings.filterwarnings('ignore')

# Try to import Gradio
try:
    import gradio as gr
    GRADIO_AVAILABLE = True
except ImportError:
    GRADIO_AVAILABLE = False
    print("⚠️ Gradio not available. Install with: pip install gradio")

# Try to import PyCaret
try:
    from pycaret.regression import predict_model, get_config
    PYCARET_AVAILABLE = True
except ImportError:
    PYCARET_AVAILABLE = False


# =============================================================================
# PREDICTION FUNCTIONS
# =============================================================================

def create_prediction_function(model: Any, feature_cols: list, df_reference: pd.DataFrame):
    """
    Creates a prediction function for Gradio interface.
    
    Parameters
    ----------
    model : Any
        Trained model
    feature_cols : list
        Feature column names
    df_reference : pd.DataFrame
        Reference data for median values
        
    Returns
    -------
    callable : Prediction function
    """
    
    # Calculate medians for default values
    medians = {}
    for col in feature_cols:
        if col in df_reference.columns:
            medians[col] = df_reference[col].median()
    
    def predict_mortality(*args):
        """Make prediction from slider inputs"""
        
        # Build input dictionary
        input_data = medians.copy()
        
        # Map args to feature columns
        slider_mapping = [
            ('adult_literacy', 0),
            ('communicable_disease_deaths', 1),
            ('ncd_mortality_pct', 2),
            ('gni_per_capita', 3),
            ('basic_sanitation', 4),
            ('physicians_density', 5),
        ]
        
        for col, idx in slider_mapping:
            if col in input_data and idx < len(args):
                input_data[col] = args[idx]
        
        # Create DataFrame
        input_df = pd.DataFrame([input_data])
        
        try:
            pred = predict_model(model, data=input_df)['prediction_label'].values[0]
            
            # Ensure non-negative
            pred = max(0.1, pred)
            
            # Classify risk
            if pred < 5:
                risk = "Very Low Risk 🟢"
            elif pred < 7:
                risk = "Low Risk 🟡"
            elif pred < 10:
                risk = "Moderate Risk 🟠"
            elif pred < 15:
                risk = "High Risk 🔴"
            else:
                risk = "Very High Risk ⚫"
            
            return f"Predicted Mortality: {pred:.2f} per 1,000\n{risk}"
            
        except Exception as e:
            return f"Prediction Error: {str(e)}"
    
    return predict_mortality


# =============================================================================
# DASHBOARD INTERFACES
# =============================================================================

def create_mortality_simulator(model: Any, df: pd.DataFrame) -> gr.Interface:
    """
    Creates interactive mortality simulator dashboard.
    
    TEACHING SCRIPT:
    ---------------
    "Let's explore the model interactively!
    
    Adjust the sliders to create hypothetical countries:
    - What happens when you increase literacy?
    - What if a country has high GNI but poor sanitation?
    - Can you find the 'tipping points' for each factor?
    
    IMPORTANT: This shows MODEL PREDICTIONS, which may not
    match reality - especially at extreme values!"
    
    Parameters
    ----------
    model : Any
        Trained prediction model
    df : pd.DataFrame
        Reference data for ranges
        
    Returns
    -------
    gr.Interface : Gradio interface
    """
    
    if not GRADIO_AVAILABLE:
        raise ImportError("Gradio not installed. Run: pip install gradio")
    
    # Get feature columns
    try:
        feature_cols = get_config('X_train').columns.tolist()
    except:
        feature_cols = ['adult_literacy', 'communicable_disease_deaths', 
                       'ncd_mortality_pct', 'gni_per_capita', 
                       'basic_sanitation', 'physicians_density']
    
    # Create prediction function
    predict_fn = create_prediction_function(model, feature_cols, df)
    
    # Calculate ranges from data
    def get_range(col, default=(0, 100)):
        if col in df.columns:
            return (max(0, df[col].min() * 0.8), df[col].max() * 1.2)
        return default
    
    def get_median(col, default=50):
        if col in df.columns:
            return float(df[col].median())
        return default
    
    # Create interface
    interface = gr.Interface(
        fn=predict_fn,
        inputs=[
            gr.Slider(
                minimum=0, maximum=100, 
                value=get_median('adult_literacy', 80),
                label="Adult Literacy Rate (%)",
                info="Higher literacy → better health outcomes"
            ),
            gr.Slider(
                minimum=0, maximum=100,
                value=get_median('communicable_disease_deaths', 20),
                label="Communicable Disease Deaths (%)",
                info="Percentage of deaths from infectious diseases"
            ),
            gr.Slider(
                minimum=0, maximum=100,
                value=get_median('ncd_mortality_pct', 70),
                label="NCD Mortality (%)",
                info="Percentage of deaths from non-communicable diseases"
            ),
            gr.Slider(
                minimum=500, maximum=80000,
                value=get_median('gni_per_capita', 10000),
                label="GNI per Capita ($)",
                info="Gross National Income per person"
            ),
            gr.Slider(
                minimum=0, maximum=100,
                value=get_median('basic_sanitation', 70),
                label="Basic Sanitation Access (%)",
                info="Population with sanitation facilities"
            ),
            gr.Slider(
                minimum=0, maximum=10,
                value=get_median('physicians_density', 2),
                label="Physicians per 1,000 Population",
                info="Healthcare workforce density"
            ),
        ],
        outputs=gr.Textbox(
            label="Model Prediction",
            lines=2
        ),
        title="🌍 Global Health Mortality Simulator",
        description="""
        **Interactive Teaching Tool**
        
        Adjust the sliders to explore how different factors affect predicted mortality rates.
        
        ⚠️ **Important Caveats:**
        - These are MODEL PREDICTIONS, not guaranteed outcomes
        - The model was trained on ecological (country-level) data
        - Extreme values may produce unreliable predictions
        - Correlation does not imply causation
        """,
        examples=[
            [95, 5, 85, 45000, 99, 3.5],  # High-income country
            [60, 50, 45, 2000, 30, 0.3],  # Low-income country
            [80, 25, 65, 10000, 75, 1.5], # Middle-income country
        ],
        cache_examples=False,
        theme=gr.themes.Soft()
    )
    
    return interface


def create_policy_comparison_dashboard(
    model: Any,
    df: pd.DataFrame
) -> gr.Blocks:
    """
    Creates dashboard for comparing policy interventions.
    
    Parameters
    ----------
    model : Any
        Trained model
    df : pd.DataFrame
        Data
        
    Returns
    -------
    gr.Blocks : Gradio Blocks interface
    """
    
    if not GRADIO_AVAILABLE:
        raise ImportError("Gradio not installed")
    
    def compare_policies(country_name, literacy_boost, sanitation_boost, physician_boost):
        """Compare multiple policy interventions for a country"""
        
        # Find country
        if 'country' in df.columns:
            country_data = df[df['country'].str.contains(country_name, case=False, na=False)]
        else:
            return "Country not found"
        
        if len(country_data) == 0:
            return f"Country '{country_name}' not found. Try: Nigeria, Brazil, India, etc."
        
        country_data = country_data.iloc[[0]]
        
        # Baseline prediction
        try:
            baseline = predict_model(model, data=country_data)['prediction_label'].values[0]
        except:
            return "Model prediction error"
        
        results = [f"🏠 Baseline Mortality: {baseline:.2f} per 1,000\n"]
        
        # Test each intervention
        scenarios = [
            ('📚 Literacy +20%', 'adult_literacy', literacy_boost / 100),
            ('🚰 Sanitation +20%', 'basic_sanitation', sanitation_boost / 100),
            ('👨‍⚕️ Physicians +20%', 'physicians_density', physician_boost / 100),
        ]
        
        impacts = []
        for name, var, boost in scenarios:
            if var not in country_data.columns:
                continue
                
            intervention_data = country_data.copy()
            new_val = intervention_data[var].values[0] * (1 + boost)
            if 'literacy' in var or 'sanitation' in var:
                new_val = min(new_val, 100)
            intervention_data[var] = new_val
            
            try:
                new_pred = predict_model(model, data=intervention_data)['prediction_label'].values[0]
                impact = baseline - new_pred
                impacts.append((name, impact))
                results.append(f"{name}: {new_pred:.2f} (Δ = {-impact:+.2f})")
            except:
                continue
        
        # Recommendation
        if impacts:
            best = max(impacts, key=lambda x: x[1])
            results.append(f"\n🏆 Best intervention: {best[0]} (saves {best[1]:.2f} per 1,000)")
        
        return "\n".join(results)
    
    # Build interface
    with gr.Blocks(theme=gr.themes.Soft()) as demo:
        gr.Markdown("# 🏛️ Policy Intervention Comparison Tool")
        gr.Markdown("""
        Compare the predicted impact of different health policy interventions 
        for a specific country.
        
        ⚠️ **Note:** These are model predictions, not guaranteed outcomes.
        """)
        
        with gr.Row():
            with gr.Column():
                country_input = gr.Textbox(
                    label="Country Name",
                    placeholder="e.g., Nigeria, Brazil, India",
                    value="Nigeria"
                )
                literacy_slider = gr.Slider(
                    0, 50, value=20,
                    label="Literacy Improvement (%)"
                )
                sanitation_slider = gr.Slider(
                    0, 50, value=20,
                    label="Sanitation Improvement (%)"
                )
                physician_slider = gr.Slider(
                    0, 50, value=20,
                    label="Physician Increase (%)"
                )
                submit_btn = gr.Button("Compare Interventions", variant="primary")
            
            with gr.Column():
                output = gr.Textbox(
                    label="Results",
                    lines=10
                )
        
        submit_btn.click(
            fn=compare_policies,
            inputs=[country_input, literacy_slider, sanitation_slider, physician_slider],
            outputs=output
        )
        
        gr.Markdown("""
        ### How to Interpret Results
        
        - **Baseline Mortality:** Current predicted death rate
        - **Δ (Delta):** Change in mortality (negative = improvement)
        - **Best Intervention:** Policy with largest mortality reduction
        
        ### Caveats
        
        1. These are ecological predictions (country-level)
        2. Model assumes interventions don't affect other variables
        3. Real-world implementation may differ
        4. Consider cost-effectiveness, not just effectiveness
        """)
    
    return demo


# =============================================================================
# LAUNCH FUNCTIONS
# =============================================================================

def launch_dashboard(
    model: Any,
    df: pd.DataFrame,
    dashboard_type: str = 'simulator',
    share: bool = True,
    **kwargs
) -> None:
    """
    Launches the interactive dashboard.
    
    Parameters
    ----------
    model : Any
        Trained model
    df : pd.DataFrame
        Data
    dashboard_type : str
        'simulator' or 'policy'
    share : bool
        Whether to create public URL
    **kwargs
        Additional arguments for Gradio launch
    """
    
    if not GRADIO_AVAILABLE:
        print("❌ Gradio not installed. Run: pip install gradio")
        return
    
    print("\n🚀 Launching Interactive Dashboard...")
    print("=" * 50)
    
    if dashboard_type == 'simulator':
        interface = create_mortality_simulator(model, df)
    elif dashboard_type == 'policy':
        interface = create_policy_comparison_dashboard(model, df)
    else:
        raise ValueError(f"Unknown dashboard type: {dashboard_type}")
    
    # Launch
    interface.launch(
        share=share,
        debug=True,
        **kwargs
    )


# =============================================================================
# MAIN EXECUTION
# =============================================================================

if __name__ == "__main__":
    print("Dashboard Module")
    print("=" * 50)
    print("\nTo launch a dashboard, run from a notebook or script:")
    print(">>> from src.dashboard import launch_dashboard")
    print(">>> launch_dashboard(model, df)")
    
    if not GRADIO_AVAILABLE:
        print("\n⚠️ Gradio is not installed. Install with:")
        print("   pip install gradio")
    else:
        print("\n✅ Gradio is available")
