"""
Visualisation Module
====================

Publication-ready visualisations for ecological analyses including:
- Funnel plots (special vs. common cause variation)
- Bubble charts (Hans Rosling style)
- Choropleth maps
- Causal DAG diagrams
- TableOne summary statistics

TEACHING NOTES:
--------------
1. FUNNEL PLOTS:
   - X-axis: Sample size (population) - log scale
   - Y-axis: Rate (mortality)
   - Control limits widen for smaller populations
   - Points OUTSIDE funnel = "special cause" variation
   - Points INSIDE funnel = "common cause" (random) variation
   
   Use for: Identifying unusual countries that warrant investigation

2. BUBBLE CHARTS:
   - Made famous by Hans Rosling's "Gapminder" talks
   - Size = population (larger = bigger bubble)
   - Colour = region or income group
   - Reveals relationships with sample size context

3. CHOROPLETH MAPS:
   - Colour gradient shows variable distribution
   - Reveals geographic patterns
   - Watch for visual distortion (large countries dominate)

4. CAUSAL DAGs:
   - Make causal assumptions EXPLICIT
   - Guide variable selection (confounders, mediators, colliders)
   - Essential for transparent causal inference

Key References:
- Spiegelhalter, D.J. (2005). Funnel plots for comparing institutional performance.
- Rosling, H. et al. (2018). Factfulness.
- Pearl, J. (2009). Causality: Models, Reasoning, and Inference.

Dependencies:
    pip install pandas numpy matplotlib seaborn plotly scipy tableone graphviz
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from typing import Dict, List, Optional, Tuple
import warnings

warnings.filterwarnings('ignore')

# Try to import optional packages
try:
    from tableone import TableOne
    TABLEONE_AVAILABLE = True
except ImportError:
    TABLEONE_AVAILABLE = False

try:
    from graphviz import Digraph
    GRAPHVIZ_AVAILABLE = True
except ImportError:
    GRAPHVIZ_AVAILABLE = False


# =============================================================================
# FUNNEL PLOTS
# =============================================================================

def create_funnel_plot(
    df: pd.DataFrame,
    rate_col: str = 'crude_death_rate',
    population_col: str = 'total_population',
    country_col: str = 'country',
    region_col: str = 'region',
    show_labels: bool = True,
    label_outliers_only: bool = True
) -> go.Figure:
    """
    Creates a proper funnel plot with statistically correct control limits.
    
    TEACHING SCRIPT:
    ---------------
    "The funnel plot is a quality improvement tool.
    
    WHY 'FUNNEL' SHAPE?
    - Larger populations have more stable rates
    - Smaller populations have more random variation
    - Control limits WIDEN as population decreases
    
    INTERPRETING OUTLIERS:
    - Points OUTSIDE the funnel are 'special cause' variation
    - These countries have rates that can't be explained by chance
    - They warrant investigation (What makes them different?)
    
    EXAMPLES:
    - A small island with very high mortality: Is there a health crisis?
    - A large country with very low mortality: What are they doing right?"
    
    Parameters
    ----------
    df : pd.DataFrame
        Data with rate and population columns
    rate_col : str
        Column containing the rate
    population_col : str
        Column containing population size
    country_col : str
        Column for country labels
    region_col : str
        Column for colour coding
    show_labels : bool
        Whether to show country labels
    label_outliers_only : bool
        Only label points outside control limits
        
    Returns
    -------
    go.Figure : Interactive funnel plot
    """
    
    # Remove missing values
    df_plot = df.dropna(subset=[rate_col, population_col]).copy()
    
    if len(df_plot) == 0:
        raise ValueError("No valid data after removing missing values")
    
    # Calculate global mean (target line)
    global_mean = df_plot[rate_col].mean()
    
    # Calculate proper control limits based on Poisson distribution
    # For a rate, SE ≈ sqrt(rate / n) where n is "person-years equivalent"
    # We use population as proxy and scale appropriately
    
    min_pop = df_plot[population_col].min()
    max_pop = df_plot[population_col].max()
    
    # Create population range for control limits (log scale)
    pop_range = np.logspace(np.log10(max(min_pop, 1000)), np.log10(max_pop), 200)
    
    # Standard error calculation (based on rate per 1000)
    # Assuming deaths follow Poisson, SE = sqrt(lambda/n) where lambda is rate
    # Scale factor to make control limits appropriate for death rates
    scale_factor = np.sqrt(global_mean * 1000)
    
    # Control limits (using normal approximation)
    se = scale_factor / np.sqrt(pop_range)
    
    upper_95 = global_mean + 1.96 * se
    lower_95 = global_mean - 1.96 * se
    upper_99 = global_mean + 2.58 * se  # 99% limits
    lower_99 = global_mean - 2.58 * se
    
    # Ensure lower limits don't go below 0
    lower_95 = np.maximum(lower_95, 0)
    lower_99 = np.maximum(lower_99, 0)
    
    # Create figure
    fig = go.Figure()
    
    # Add control limit bands (99.8% - outer)
    fig.add_trace(go.Scatter(
        x=np.concatenate([pop_range, pop_range[::-1]]),
        y=np.concatenate([upper_99, lower_99[::-1]]),
        fill='toself',
        fillcolor='rgba(255, 200, 200, 0.3)',
        line=dict(color='rgba(255, 200, 200, 0)'),
        name='99% Control Limits',
        showlegend=True,
        hoverinfo='skip'
    ))
    
    # Add control limit bands (95% - inner)
    fig.add_trace(go.Scatter(
        x=np.concatenate([pop_range, pop_range[::-1]]),
        y=np.concatenate([upper_95, lower_95[::-1]]),
        fill='toself',
        fillcolor='rgba(200, 255, 200, 0.3)',
        line=dict(color='rgba(200, 255, 200, 0)'),
        name='95% Control Limits',
        showlegend=True,
        hoverinfo='skip'
    ))
    
    # Add target line (global mean)
    fig.add_trace(go.Scatter(
        x=pop_range,
        y=[global_mean] * len(pop_range),
        mode='lines',
        line=dict(color='black', width=2, dash='dash'),
        name=f'Global Mean ({global_mean:.1f})'
    ))
    
    # Determine outliers for labelling
    df_plot['is_outlier'] = False
    for idx, row in df_plot.iterrows():
        pop = row[population_col]
        rate = row[rate_col]
        se_country = scale_factor / np.sqrt(pop)
        upper = global_mean + 1.96 * se_country
        lower = max(0, global_mean - 1.96 * se_country)
        
        if rate > upper or rate < lower:
            df_plot.loc[idx, 'is_outlier'] = True
    
    # Add data points by region
    if region_col in df_plot.columns:
        regions = df_plot[region_col].dropna().unique()
        colors = px.colors.qualitative.Set1
        
        for i, region in enumerate(regions):
            df_region = df_plot[df_plot[region_col] == region]
            
            # Determine which points to label
            if label_outliers_only:
                text_labels = df_region.apply(
                    lambda x: x[country_col] if x['is_outlier'] else '', axis=1
                )
            else:
                text_labels = df_region[country_col] if show_labels else None
            
            fig.add_trace(go.Scatter(
                x=df_region[population_col],
                y=df_region[rate_col],
                mode='markers+text' if show_labels else 'markers',
                marker=dict(
                    size=10,
                    color=colors[i % len(colors)],
                    opacity=0.7,
                    line=dict(width=1, color='white')
                ),
                text=text_labels,
                textposition='top right',
                textfont=dict(size=9),
                name=region,
                hovertemplate=f'<b>%{{customdata}}</b><br>' +
                              f'{rate_col}: %{{y:.1f}}<br>' +
                              f'Population: %{{x:,.0f}}<extra></extra>',
                customdata=df_region[country_col]
            ))
    else:
        fig.add_trace(go.Scatter(
            x=df_plot[population_col],
            y=df_plot[rate_col],
            mode='markers',
            marker=dict(size=10, color='steelblue', opacity=0.7),
            name='Countries',
            hovertemplate='<b>%{customdata}</b><br>' +
                          f'{rate_col}: %{{y:.1f}}<br>' +
                          f'Population: %{{x:,.0f}}<extra></extra>',
            customdata=df_plot[country_col]
        ))
    
    fig.update_layout(
        title=f'<b>Funnel Plot: {rate_col.replace("_", " ").title()}</b><br>' +
              '<span style="font-size:12px">Points outside control limits indicate "special cause" variation</span>',
        xaxis_title='Population (Log Scale)',
        yaxis_title=rate_col.replace('_', ' ').title(),
        xaxis_type='log',
        height=600,
        legend=dict(x=0.01, y=0.99, bgcolor='rgba(255,255,255,0.8)')
    )
    
    # Count outliers
    n_outliers = df_plot['is_outlier'].sum()
    
    # Add annotation
    fig.add_annotation(
        x=0.99, y=0.01,
        xref='paper', yref='paper',
        text=f'Outliers (outside 95% limits): {n_outliers} countries',
        showarrow=False,
        font=dict(size=12),
        bgcolor='white',
        bordercolor='gray',
        borderwidth=1
    )
    
    return fig


# =============================================================================
# BUBBLE CHARTS
# =============================================================================

def create_bubble_plot(
    df: pd.DataFrame,
    x_var: str,
    y_var: str = 'crude_death_rate',
    size_var: str = 'total_population',
    color_var: str = 'region',
    hover_name: str = 'country',
    log_x: bool = False,
    log_y: bool = False,
    title: Optional[str] = None,
    trendline: bool = True
) -> go.Figure:
    """
    Creates Hans Rosling-style bubble chart.
    
    TEACHING SCRIPT:
    ---------------
    "Hans Rosling revolutionised data presentation with bubble charts.
    
    Each bubble is a country:
    - Position shows the relationship (x vs y)
    - SIZE shows importance (population)
    - COLOUR shows grouping (region)
    
    KEY INSIGHTS:
    1. Large bubbles matter more (more people affected)
    2. Outliers might be small countries (extreme but low impact)
    3. Regional clustering shows geographic patterns
    
    Interactive features:
    - Hover for country details
    - Zoom to explore clusters
    - Click legend to show/hide regions"
    
    Parameters
    ----------
    df : pd.DataFrame
        Data
    x_var : str
        X-axis variable
    y_var : str
        Y-axis variable
    size_var : str
        Variable for bubble size
    color_var : str
        Variable for colour coding
    hover_name : str
        Column for hover labels
    log_x, log_y : bool
        Whether to use log scales
    title : str, optional
        Plot title
    trendline : bool
        Whether to add LOWESS trendline
        
    Returns
    -------
    go.Figure : Interactive bubble chart
    """
    
    # Prepare data
    required_cols = [x_var, y_var]
    if size_var:
        required_cols.append(size_var)
    
    df_plot = df.dropna(subset=required_cols).copy()
    
    if title is None:
        title = f'<b>{y_var.replace("_", " ").title()} vs {x_var.replace("_", " ").title()}</b>'
    
    # Create bubble chart
    fig = px.scatter(
        df_plot,
        x=x_var,
        y=y_var,
        size=size_var if size_var in df_plot.columns else None,
        color=color_var if color_var in df_plot.columns else None,
        hover_name=hover_name if hover_name in df_plot.columns else None,
        log_x=log_x,
        log_y=log_y,
        size_max=60,
        title=title,
        labels={
            x_var: x_var.replace('_', ' ').title(),
            y_var: y_var.replace('_', ' ').title()
        },
        color_discrete_sequence=px.colors.qualitative.Set1
    )
    
    # Add trendline if requested
    if trendline:
        try:
            from scipy.ndimage import uniform_filter1d
            
            # Sort by x for proper line
            df_sorted = df_plot.sort_values(x_var)
            x_vals = df_sorted[x_var].values
            y_vals = df_sorted[y_var].values
            
            if log_x:
                x_vals = np.log10(x_vals)
            
            # Fit LOWESS-like smooth
            window = max(5, len(x_vals) // 10)
            y_smooth = uniform_filter1d(y_vals, size=window)
            
            if log_x:
                x_line = 10 ** x_vals
            else:
                x_line = x_vals
            
            fig.add_trace(go.Scatter(
                x=x_line,
                y=y_smooth,
                mode='lines',
                line=dict(color='black', width=2, dash='dash'),
                name='Trend',
                showlegend=True
            ))
        except:
            pass
    
    fig.update_layout(
        height=600,
        legend=dict(orientation='h', y=-0.15)
    )
    
    return fig


# =============================================================================
# CHOROPLETH MAPS
# =============================================================================

def create_world_map(
    df: pd.DataFrame,
    variable: str = 'crude_death_rate',
    iso_col: str = 'iso3_code',
    hover_name: str = 'country',
    color_scale: str = 'Plasma',
    title: Optional[str] = None,
    projection: str = 'natural earth'
) -> go.Figure:
    """
    Creates interactive world choropleth map.
    
    TEACHING SCRIPT:
    ---------------
    "Maps reveal GEOGRAPHIC patterns that tables hide.
    
    Patterns to look for:
    1. REGIONAL CLUSTERING: Are high values concentrated?
    2. LATITUDE GRADIENTS: North-South differences?
    3. DEVELOPMENT CORRIDORS: Trade routes, colonial history?
    
    CAUTION:
    - Large countries visually dominate (Mercator projection issue)
    - Missing data appears blank
    - Colour perception varies - test with colourblind palette"
    
    Parameters
    ----------
    df : pd.DataFrame
        Data
    variable : str
        Variable to map
    iso_col : str
        ISO country code column
    hover_name : str
        Column for hover labels
    color_scale : str
        Plotly colour scale
    title : str, optional
        Map title
    projection : str
        Map projection
        
    Returns
    -------
    go.Figure : Interactive choropleth map
    """
    
    df_plot = df.dropna(subset=[variable, iso_col]).copy()
    
    if title is None:
        title = f'<b>Global Distribution: {variable.replace("_", " ").title()}</b>'
    
    fig = px.choropleth(
        df_plot,
        locations=iso_col,
        color=variable,
        hover_name=hover_name if hover_name in df_plot.columns else None,
        color_continuous_scale=color_scale,
        title=title,
        projection=projection,
        labels={variable: variable.replace('_', ' ').title()}
    )
    
    fig.update_layout(
        height=600,
        geo=dict(
            showframe=False,
            showcoastlines=True,
            coastlinecolor='lightgray',
            showland=True,
            landcolor='whitesmoke',
            showocean=True,
            oceancolor='aliceblue'
        ),
        margin=dict(l=0, r=0, t=50, b=0)
    )
    
    return fig


# =============================================================================
# CAUSAL DAG
# =============================================================================

def create_dag_visualisation(
    save_path: Optional[str] = None,
    format: str = 'png'
) -> Optional[object]:
    """
    Creates a causal DAG for the hierarchical mortality model.
    
    TEACHING SCRIPT:
    ---------------
    "A Directed Acyclic Graph (DAG) makes our causal ASSUMPTIONS explicit.
    
    Our assumed structure:
    
    DISTAL ──────► INTERMEDIATE ──────► PROXIMATE ──────► MORTALITY
    (GNI, Education)  (Healthcare,      (Disease burden,
                       Sanitation)       Risk factors)
    
    KEY DAG CONCEPTS:
    1. CONFOUNDERS: Common causes of exposure and outcome
       - Must control for these to avoid bias
    
    2. MEDIATORS: Variables on the causal pathway
       - Controlling may hide the total effect
    
    3. COLLIDERS: Common effects of two variables
       - NEVER control for colliders (induces bias)
    
    In our model:
    - Intermediate factors MEDIATE distal effects
    - We might have unmeasured confounders (U)
    - Age structure could confound everything"
    
    Parameters
    ----------
    save_path : str, optional
        Path to save the diagram
    format : str
        Output format ('png', 'svg', 'pdf')
        
    Returns
    -------
    graphviz.Digraph or None
    """
    
    if not GRAPHVIZ_AVAILABLE:
        print("⚠️ Graphviz not available. Install with: pip install graphviz")
        print("   Also need system graphviz: apt-get install graphviz")
        
        # Return text-based DAG
        dag_text = """
        CAUSAL DAG (Text Version):
        
        ┌─────────────────────────────────────────────────────────────────┐
        │                                                                 │
        │    ┌───────────┐       ┌──────────────┐       ┌──────────────┐ │
        │    │  DISTAL   │──────►│ INTERMEDIATE │──────►│  PROXIMATE   │ │
        │    │ (GNI,     │       │ (Healthcare, │       │ (Disease     │ │
        │    │ Education)│       │ Sanitation)  │       │  burden)     │ │
        │    └─────┬─────┘       └──────┬───────┘       └──────┬───────┘ │
        │          │                    │                      │         │
        │          │                    │                      ▼         │
        │          │                    │               ┌──────────────┐ │
        │          └────────────────────┴──────────────►│  MORTALITY   │ │
        │                                               └──────────────┘ │
        │                                                      ▲         │
        │    ┌───────────┐                                     │         │
        │    │UNMEASURED │─────────────────────────────────────┘         │
        │    │CONFOUNDERS│                                               │
        │    │(U: Age,   │                                               │
        │    │ History)  │                                               │
        │    └───────────┘                                               │
        │                                                                 │
        └─────────────────────────────────────────────────────────────────┘
        
        KEY:
        ───► = Causal effect
        U    = Unmeasured confounders (potential bias)
        """
        print(dag_text)
        return None
    
    # Create DAG with graphviz
    dag = Digraph('Mortality_DAG')
    dag.attr(rankdir='LR', size='12,8', dpi='150')
    dag.attr('node', shape='box', style='rounded,filled', fontsize='11')
    
    # Node styling
    distal_style = {'fillcolor': '#e3f2fd', 'color': '#1565c0'}
    inter_style = {'fillcolor': '#fff3e0', 'color': '#e65100'}
    prox_style = {'fillcolor': '#fce4ec', 'color': '#c2185b'}
    outcome_style = {'fillcolor': '#ffebee', 'color': '#b71c1c'}
    confound_style = {'fillcolor': '#f5f5f5', 'color': '#757575', 'style': 'dashed,rounded'}
    
    # Distal nodes
    with dag.subgraph(name='cluster_distal') as c:
        c.attr(label='DISTAL\n(Root Causes)', style='dashed', color='#1565c0')
        c.node('gni', 'GNI per Capita', **distal_style)
        c.node('edu', 'Education\n(Literacy)', **distal_style)
        c.node('ineq', 'Inequality\n(Gini)', **distal_style)
    
    # Intermediate nodes
    with dag.subgraph(name='cluster_inter') as c:
        c.attr(label='INTERMEDIATE\n(Systems)', style='dashed', color='#e65100')
        c.node('health_sys', 'Healthcare\nCapacity', **inter_style)
        c.node('infra', 'Infrastructure\n(Water, Sanitation)', **inter_style)
    
    # Proximate nodes
    with dag.subgraph(name='cluster_prox') as c:
        c.attr(label='PROXIMATE\n(Direct Causes)', style='dashed', color='#c2185b')
        c.node('disease', 'Disease\nBurden', **prox_style)
        c.node('risk', 'Risk\nFactors', **prox_style)
    
    # Outcome
    dag.node('mortality', 'MORTALITY', **outcome_style)
    
    # Unmeasured confounders
    dag.node('U', 'Unmeasured\nConfounders\n(Age, History)', **confound_style)
    
    # Edges: Distal → Intermediate
    dag.edge('gni', 'health_sys')
    dag.edge('gni', 'infra')
    dag.edge('edu', 'health_sys')
    dag.edge('edu', 'infra')
    
    # Edges: Intermediate → Proximate
    dag.edge('health_sys', 'disease')
    dag.edge('health_sys', 'risk')
    dag.edge('infra', 'disease')
    
    # Edges: Proximate → Outcome
    dag.edge('disease', 'mortality')
    dag.edge('risk', 'mortality')
    
    # Direct effects (bypassing mediators)
    dag.edge('gni', 'mortality', style='dashed', color='gray')
    dag.edge('edu', 'mortality', style='dashed', color='gray')
    
    # Confounding
    dag.edge('U', 'gni', style='dashed', color='red')
    dag.edge('U', 'mortality', style='dashed', color='red')
    
    # Save if path provided
    if save_path:
        dag.render(save_path, format=format, cleanup=True)
        print(f"DAG saved to {save_path}.{format}")
    
    return dag


# =============================================================================
# TABLE ONE (Summary Statistics)
# =============================================================================

def create_table_one(
    df: pd.DataFrame,
    groupby: str = 'region',
    columns: Optional[List[str]] = None,
    categorical: Optional[List[str]] = None,
    nonnormal: Optional[List[str]] = None,
    pval: bool = True
) -> pd.DataFrame:
    """
    Creates publication-ready Table 1 summary statistics.
    
    TEACHING SCRIPT:
    ---------------
    "Table 1 is the first table in most epidemiology papers.
    It shows:
    - Sample characteristics
    - Distribution across groups
    - Statistical tests for group differences
    
    For ecological studies:
    - Groups might be regions or income levels
    - Continuous variables: mean (SD) or median [IQR]
    - Categorical variables: n (%)
    - P-values test whether groups differ"
    
    Parameters
    ----------
    df : pd.DataFrame
        Data
    groupby : str
        Stratification variable
    columns : list, optional
        Variables to include
    categorical : list, optional
        Categorical variables
    nonnormal : list, optional
        Variables to report as median [IQR]
    pval : bool
        Whether to include p-values
        
    Returns
    -------
    pd.DataFrame : Table 1
    """
    
    if not TABLEONE_AVAILABLE:
        print("⚠️ tableone not available. Install with: pip install tableone")
        
        # Basic summary without tableone
        if columns is None:
            columns = df.select_dtypes(include=[np.number]).columns.tolist()
        
        summary = df.groupby(groupby)[columns].agg(['count', 'mean', 'std']).round(2)
        return summary
    
    # Default columns
    if columns is None:
        columns = [c for c in df.select_dtypes(include=[np.number]).columns 
                   if c not in ['latitude', 'longitude']]
    
    # Filter to existing columns
    columns = [c for c in columns if c in df.columns]
    
    # Create Table 1
    table1 = TableOne(
        df,
        columns=columns,
        categorical=categorical or [],
        groupby=groupby if groupby in df.columns else None,
        nonnormal=nonnormal or [],
        pval=pval,
        htest_name=True
    )
    
    return table1


# =============================================================================
# MAIN EXECUTION (for testing)
# =============================================================================

if __name__ == "__main__":
    print("Testing visualisation module...")
    
    # Check available packages
    print(f"\n✅ TableOne available: {TABLEONE_AVAILABLE}")
    print(f"✅ Graphviz available: {GRAPHVIZ_AVAILABLE}")
    
    # Test DAG creation
    print("\nCreating causal DAG...")
    dag = create_dag_visualisation()
    
    print("\nSee notebooks for complete usage examples.")
