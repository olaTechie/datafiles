"""
Exploratory Data Analysis Module
================================

Comprehensive EDA tools for ecological analysis including the critical
ecological fallacy demonstration and correlation analysis.

TEACHING NOTES:
--------------
1. ALWAYS start with the ecological fallacy demo - students must understand
   the fundamental limitation before interpreting any results.

2. Correlation ≠ Causation, but in ecological studies we also have
   Correlation ≠ Individual-level correlation (Robinson, 1950)

3. The hierarchical correlation analysis helps identify potential
   mediation pathways (Baron & Kenny framework).

Key References:
- Robinson, W.S. (1950). Ecological correlations and the behavior of individuals.
- Greenland, S. (2001). Ecologic versus individual-level sources of bias.
- Morgenstern, H. (1995). Ecologic studies in epidemiology.

Dependencies:
    pip install pandas numpy matplotlib seaborn plotly scipy
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from typing import Tuple, List, Optional
import warnings

warnings.filterwarnings('ignore')

# Set style
plt.style.use('seaborn-v0_8-whitegrid')
sns.set_palette("husl")


# =============================================================================
# ECOLOGICAL FALLACY DEMONSTRATION
# =============================================================================

def demonstrate_ecological_fallacy(save_path: Optional[str] = None) -> plt.Figure:
    """
    Creates a powerful visual demonstration of the ecological fallacy
    using Simpson's Paradox.
    
    TEACHING SCRIPT:
    ---------------
    "Before we analyse any data, we need to understand a CRITICAL limitation.
    
    Look at the left panel - at the COUNTRY level, richer countries appear
    to have HIGHER mortality. This is because rich countries have older
    populations (demographic transition).
    
    But look at the right panel - WITHIN each country, richer individuals
    likely live longer. The aggregate relationship is OPPOSITE to the
    individual relationship.
    
    This is the ECOLOGICAL FALLACY - we cannot infer individual-level
    relationships from aggregate data. Our ecological analysis can identify
    associations, but claims about individuals require individual-level data."
    
    Parameters
    ----------
    save_path : str, optional
        Path to save the figure
        
    Returns
    -------
    plt.Figure : The demonstration figure
    
    Example
    -------
    >>> fig = demonstrate_ecological_fallacy()
    >>> plt.show()
    """
    
    np.random.seed(42)
    
    # Create synthetic data demonstrating Simpson's Paradox
    # Country A: Rich but Old (High Mortality due to age structure)
    # Country B: Poor but Young (Low Mortality due to age structure)
    
    # Country A (Rich, Old)
    n_a = 500
    c1_income = np.random.normal(50000, 10000, n_a)
    c1_age = np.random.normal(65, 10, n_a)  # Older population
    # Within-country: higher income = lower mortality (protective)
    c1_mortality = 15 - 0.00005 * c1_income + 0.2 * c1_age + np.random.normal(0, 2, n_a)
    
    # Country B (Poor, Young)
    n_b = 500
    c2_income = np.random.normal(5000, 2000, n_b)
    c2_age = np.random.normal(30, 8, n_b)  # Younger population
    # Same within-country relationship
    c2_mortality = 15 - 0.00005 * c2_income + 0.2 * c2_age + np.random.normal(0, 2, n_b)
    
    # Country C (Middle)
    n_c = 500
    c3_income = np.random.normal(20000, 5000, n_c)
    c3_age = np.random.normal(45, 12, n_c)
    c3_mortality = 15 - 0.00005 * c3_income + 0.2 * c3_age + np.random.normal(0, 2, n_c)
    
    # Create figure
    fig, axes = plt.subplots(1, 3, figsize=(16, 5))
    
    # Panel 1: Ecological View (Country Averages)
    ax1 = axes[0]
    countries = ['Country A\n(Rich, Old)', 'Country B\n(Poor, Young)', 'Country C\n(Middle)']
    avg_incomes = [c1_income.mean(), c2_income.mean(), c3_income.mean()]
    avg_mortality = [c1_mortality.mean(), c2_mortality.mean(), c3_mortality.mean()]
    colors = ['#3498db', '#e74c3c', '#2ecc71']
    
    for i, (inc, mort, col, name) in enumerate(zip(avg_incomes, avg_mortality, colors, countries)):
        ax1.scatter([inc], [mort], s=800, c=col, alpha=0.8, edgecolors='black', linewidth=2)
        ax1.annotate(name, (inc, mort), textcoords="offset points", 
                     xytext=(0, 25), ha='center', fontsize=10, fontweight='bold')
    
    # Add trend line
    z = np.polyfit(avg_incomes, avg_mortality, 1)
    p = np.poly1d(z)
    x_line = np.linspace(0, 55000, 100)
    ax1.plot(x_line, p(x_line), 'k--', alpha=0.5, linewidth=2, label='Ecological trend')
    
    ax1.set_xlabel('Average Income ($)', fontsize=12)
    ax1.set_ylabel('Average Mortality Rate', fontsize=12)
    ax1.set_title('🔴 ECOLOGICAL VIEW\n(Country Averages Only)', fontsize=14, fontweight='bold')
    ax1.set_xlim(0, 60000)
    
    # Add correlation annotation
    r_eco, _ = stats.pearsonr(avg_incomes, avg_mortality)
    ax1.annotate(f'Ecological r = {r_eco:.2f}\n"Higher income → Higher mortality"?', 
                 xy=(0.05, 0.95), xycoords='axes fraction',
                 fontsize=11, color='red', fontweight='bold',
                 verticalalignment='top',
                 bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
    
    # Panel 2: Individual View (Within Countries)
    ax2 = axes[1]
    ax2.scatter(c1_income, c1_mortality, alpha=0.3, c='#3498db', s=20, label='Country A')
    ax2.scatter(c2_income, c2_mortality, alpha=0.3, c='#e74c3c', s=20, label='Country B')
    ax2.scatter(c3_income, c3_mortality, alpha=0.3, c='#2ecc71', s=20, label='Country C')
    
    # Add within-country trend lines
    for income, mort, col in [(c1_income, c1_mortality, '#3498db'),
                               (c2_income, c2_mortality, '#e74c3c'),
                               (c3_income, c3_mortality, '#2ecc71')]:
        z = np.polyfit(income, mort, 1)
        p = np.poly1d(z)
        x_range = np.linspace(income.min(), income.max(), 50)
        ax2.plot(x_range, p(x_range), c=col, linewidth=2, alpha=0.8)
    
    ax2.set_xlabel('Individual Income ($)', fontsize=12)
    ax2.set_ylabel('Individual Mortality Risk', fontsize=12)
    ax2.set_title('🟢 INDIVIDUAL VIEW\n(Within-Country Relationships)', fontsize=14, fontweight='bold')
    ax2.legend(loc='upper right')
    
    # Add annotation
    ax2.annotate('Within each country:\nHigher income → Lower mortality\n(Negative slope)', 
                 xy=(0.05, 0.95), xycoords='axes fraction',
                 fontsize=11, color='green', fontweight='bold',
                 verticalalignment='top',
                 bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
    
    # Panel 3: The DAG explanation
    ax3 = axes[2]
    ax3.set_xlim(0, 10)
    ax3.set_ylim(0, 10)
    ax3.axis('off')
    
    # Draw the DAG
    # Nodes
    nodes = {
        'Country\nWealth': (2, 8),
        'Age\nStructure': (5, 8),
        'Country\nMortality': (8, 8),
        'Individual\nIncome': (2, 3),
        'Individual\nMortality': (8, 3),
    }
    
    for name, (x, y) in nodes.items():
        circle = plt.Circle((x, y), 0.8, color='lightblue', ec='navy', linewidth=2)
        ax3.add_patch(circle)
        ax3.text(x, y, name, ha='center', va='center', fontsize=9, fontweight='bold')
    
    # Arrows
    ax3.annotate('', xy=(4.2, 8), xytext=(2.8, 8),
                 arrowprops=dict(arrowstyle='->', color='black', lw=2))
    ax3.annotate('', xy=(7.2, 8), xytext=(5.8, 8),
                 arrowprops=dict(arrowstyle='->', color='black', lw=2))
    ax3.annotate('', xy=(7.2, 3), xytext=(2.8, 3),
                 arrowprops=dict(arrowstyle='->', color='green', lw=2))
    
    # Labels
    ax3.text(3.5, 8.5, '+', fontsize=14, fontweight='bold', color='red')
    ax3.text(6.5, 8.5, '+', fontsize=14, fontweight='bold', color='red')
    ax3.text(5, 2.5, '– (protective)', fontsize=10, fontweight='bold', color='green')
    
    ax3.set_title('🔶 CAUSAL EXPLANATION\n(Confounding by Age Structure)', 
                  fontsize=14, fontweight='bold')
    
    # Add explanation text
    explanation = """
    KEY INSIGHT:
    
    At ECOLOGICAL level: Wealthy countries 
    have older populations → higher mortality
    (POSITIVE association)
    
    At INDIVIDUAL level: Wealthy individuals 
    have better healthcare → lower mortality
    (NEGATIVE association)
    
    The ecological correlation is confounded
    by population age structure!
    """
    ax3.text(5, 0.5, explanation, ha='center', va='bottom', fontsize=9,
             bbox=dict(boxstyle='round', facecolor='lightyellow', alpha=0.9))
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"Figure saved to {save_path}")
    
    return fig


def demonstrate_ecological_fallacy_interactive() -> go.Figure:
    """
    Creates an interactive Plotly version of the ecological fallacy demo.
    
    TEACHING NOTE:
    -------------
    Use this version for online teaching where students can hover
    over data points to explore the relationships themselves.
    
    Returns
    -------
    go.Figure : Interactive Plotly figure
    """
    
    np.random.seed(42)
    
    # Generate data for three countries
    data = []
    
    countries = [
        ('Japan (Rich, Old)', 50000, 10000, 68, 8),
        ('Nigeria (Poor, Young)', 5000, 2000, 28, 10),
        ('Brazil (Middle)', 15000, 5000, 45, 12),
    ]
    
    for name, mean_inc, std_inc, mean_age, std_age in countries:
        n = 300
        income = np.random.normal(mean_inc, std_inc, n)
        age = np.random.normal(mean_age, std_age, n)
        # Within-country: income protective, age increases risk
        mortality = 12 - 0.00004 * income + 0.15 * age + np.random.normal(0, 1.5, n)
        
        for inc, mort in zip(income, mortality):
            data.append({
                'country': name,
                'income': inc,
                'mortality': max(0, mort),
                'type': 'Individual'
            })
        
        # Add country average
        data.append({
            'country': name,
            'income': np.mean(income),
            'mortality': np.mean(mortality),
            'type': 'Country Average'
        })
    
    df = pd.DataFrame(data)
    
    # Create subplots
    fig = make_subplots(
        rows=1, cols=2,
        subplot_titles=(
            '<b>Ecological View (Country Averages)</b><br>Appears: Richer = Higher Mortality',
            '<b>Individual View (Within Countries)</b><br>Reality: Richer = Lower Mortality'
        )
    )
    
    # Plot 1: Country averages only
    df_avg = df[df['type'] == 'Country Average']
    fig.add_trace(
        go.Scatter(
            x=df_avg['income'],
            y=df_avg['mortality'],
            mode='markers+text',
            marker=dict(size=30, color=['blue', 'red', 'green']),
            text=df_avg['country'].str.split('(').str[0],
            textposition='top center',
            name='Country Averages',
            showlegend=False
        ),
        row=1, col=1
    )
    
    # Add trend line to ecological view
    z = np.polyfit(df_avg['income'], df_avg['mortality'], 1)
    p = np.poly1d(z)
    x_line = np.linspace(df_avg['income'].min() - 5000, df_avg['income'].max() + 5000, 100)
    fig.add_trace(
        go.Scatter(
            x=x_line, y=p(x_line),
            mode='lines',
            line=dict(dash='dash', color='black'),
            name='Ecological Trend (Wrong!)',
            showlegend=False
        ),
        row=1, col=1
    )
    
    # Plot 2: Individual data
    df_ind = df[df['type'] == 'Individual']
    colors = {'Japan (Rich, Old)': 'blue', 'Nigeria (Poor, Young)': 'red', 
              'Brazil (Middle)': 'green'}
    
    for country in df_ind['country'].unique():
        df_c = df_ind[df_ind['country'] == country]
        fig.add_trace(
            go.Scatter(
                x=df_c['income'],
                y=df_c['mortality'],
                mode='markers',
                marker=dict(size=5, color=colors[country], opacity=0.4),
                name=country.split('(')[0].strip()
            ),
            row=1, col=2
        )
    
    fig.update_layout(
        height=500,
        title_text="<b>The Ecological Fallacy Demonstration</b><br>" +
                   "<span style='color:red'>Country-level correlations can be OPPOSITE to individual-level!</span>",
        showlegend=True,
        legend=dict(x=0.7, y=0.05)
    )
    
    fig.update_xaxes(title_text="Income ($)", row=1, col=1)
    fig.update_xaxes(title_text="Individual Income ($)", row=1, col=2)
    fig.update_yaxes(title_text="Mortality Rate", row=1, col=1)
    fig.update_yaxes(title_text="Individual Mortality Risk", row=1, col=2)
    
    return fig


# =============================================================================
# CORRELATION ANALYSIS
# =============================================================================

def analyze_correlations_hierarchical(
    df: pd.DataFrame,
    outcome: str = 'crude_death_rate',
    show_plot: bool = True
) -> Tuple[go.Figure, pd.Series]:
    """
    Performs hierarchical correlation analysis with interpretable visualisation.
    
    TEACHING SCRIPT:
    ---------------
    "Let's examine which variables correlate most strongly with mortality.
    
    IMPORTANT: Remember these are ECOLOGICAL correlations - they describe
    relationships between COUNTRIES, not individuals.
    
    Look for:
    1. Which determinant level has strongest correlations?
    2. Are there surprising relationships (e.g., NCD mortality positive)?
    3. Which variables might be confounded by development level?"
    
    Parameters
    ----------
    df : pd.DataFrame
        Dataset with outcome and predictors
    outcome : str
        Name of outcome variable
    show_plot : bool
        Whether to display the plot
        
    Returns
    -------
    tuple : (Plotly figure, Series of correlations with outcome)
    """
    
    # Select numeric columns
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    
    # Remove coordinate columns and population (not predictors)
    exclude = ['latitude', 'longitude', 'total_population']
    numeric_cols = [c for c in numeric_cols if c not in exclude]
    
    # Calculate correlation matrix
    corr_matrix = df[numeric_cols].corr()
    
    # Extract correlations with outcome
    outcome_corr = corr_matrix[outcome].drop(outcome).sort_values()
    
    # Create subplots
    fig = make_subplots(
        rows=1, cols=2,
        subplot_titles=(
            '<b>Full Correlation Matrix</b>',
            f'<b>Correlations with {outcome.replace("_", " ").title()}</b>'
        ),
        column_widths=[0.6, 0.4],
        horizontal_spacing=0.12
    )
    
    # Heatmap
    fig.add_trace(
        go.Heatmap(
            z=corr_matrix.values,
            x=corr_matrix.columns,
            y=corr_matrix.columns,
            colorscale='RdBu_r',
            zmid=0,
            text=np.round(corr_matrix.values, 2),
            texttemplate='%{text}',
            textfont={"size": 8},
            showscale=True,
            colorbar=dict(x=0.45, len=0.9)
        ),
        row=1, col=1
    )
    
    # Bar chart of correlations with outcome
    colors = ['#e74c3c' if x < 0 else '#27ae60' for x in outcome_corr.values]
    
    fig.add_trace(
        go.Bar(
            x=outcome_corr.values,
            y=outcome_corr.index,
            orientation='h',
            marker_color=colors,
            text=np.round(outcome_corr.values, 2),
            textposition='outside',
            showlegend=False
        ),
        row=1, col=2
    )
    
    fig.update_layout(
        height=600,
        title_text="<b>Hierarchical Correlation Analysis</b><br>" +
                   "<span style='font-size:12px'>Red = Negative correlation (protective), " +
                   "Green = Positive correlation (risk factor)</span>",
    )
    
    fig.update_xaxes(title_text="Correlation Coefficient", row=1, col=2)
    fig.update_xaxes(tickangle=45, row=1, col=1)
    
    if show_plot:
        fig.show()
    
    # Print interpretation guide
    print("\n" + "=" * 60)
    print("📊 CORRELATION INTERPRETATION GUIDE")
    print("=" * 60)
    
    print("\n🔴 STRONG POSITIVE CORRELATIONS (Risk Factors):")
    print("   Higher values associated with HIGHER mortality")
    for var in outcome_corr[outcome_corr > 0.4].index:
        print(f"   • {var}: r = {outcome_corr[var]:.3f}")
    
    print("\n🟢 STRONG NEGATIVE CORRELATIONS (Protective):")
    print("   Higher values associated with LOWER mortality")
    for var in outcome_corr[outcome_corr < -0.4].index:
        print(f"   • {var}: r = {outcome_corr[var]:.3f}")
    
    print("\n⚠️  CAUTION: These are ECOLOGICAL correlations!")
    print("   Individual-level relationships may differ.")
    print("=" * 60)
    
    return fig, outcome_corr


def create_scatter_matrix(
    df: pd.DataFrame,
    variables: Optional[List[str]] = None,
    color_by: str = 'region'
) -> go.Figure:
    """
    Creates an interactive scatter plot matrix for key variables.
    
    TEACHING NOTE:
    -------------
    Scatter matrices help identify:
    1. Non-linear relationships (curved patterns)
    2. Threshold effects (relationships that change at certain values)
    3. Outliers and influential observations
    4. Multicollinearity (highly correlated predictors)
    
    Parameters
    ----------
    df : pd.DataFrame
        Dataset
    variables : list, optional
        Variables to include (default: key mortality predictors)
    color_by : str
        Variable to use for colour coding
        
    Returns
    -------
    go.Figure : Interactive scatter matrix
    """
    
    if variables is None:
        variables = [
            'crude_death_rate',
            'gni_per_capita',
            'adult_literacy',
            'physicians_density',
            'communicable_disease_deaths'
        ]
    
    # Filter to existing columns
    variables = [v for v in variables if v in df.columns]
    
    # Create scatter matrix
    fig = px.scatter_matrix(
        df,
        dimensions=variables,
        color=color_by if color_by in df.columns else None,
        hover_name='country' if 'country' in df.columns else None,
        title="<b>Scatter Plot Matrix</b><br>" +
              "<span style='font-size:12px'>Look for non-linear patterns and outliers</span>",
        opacity=0.6,
        height=800
    )
    
    fig.update_traces(diagonal_visible=False)
    fig.update_layout(
        title_x=0.5,
        legend=dict(orientation='h', y=-0.1)
    )
    
    return fig


def create_distribution_plots(
    df: pd.DataFrame,
    variables: Optional[List[str]] = None,
    by_region: bool = True
) -> go.Figure:
    """
    Creates distribution plots for key variables, optionally stratified by region.
    
    TEACHING NOTE:
    -------------
    Understanding distributions is crucial because:
    1. Skewed variables may need transformation
    2. Multimodal distributions suggest subgroups
    3. Outliers can dominate regression results
    
    Parameters
    ----------
    df : pd.DataFrame
        Dataset
    variables : list, optional
        Variables to plot
    by_region : bool
        Whether to stratify by region
        
    Returns
    -------
    go.Figure : Distribution plots
    """
    
    if variables is None:
        variables = ['crude_death_rate', 'gni_per_capita', 'adult_literacy', 
                     'physicians_density']
    
    variables = [v for v in variables if v in df.columns]
    n_vars = len(variables)
    
    if by_region and 'region' in df.columns:
        fig = make_subplots(
            rows=n_vars, cols=1,
            subplot_titles=[v.replace('_', ' ').title() for v in variables]
        )
        
        for i, var in enumerate(variables, 1):
            for region in df['region'].dropna().unique():
                df_r = df[df['region'] == region]
                fig.add_trace(
                    go.Histogram(
                        x=df_r[var],
                        name=region,
                        opacity=0.6,
                        showlegend=(i == 1)
                    ),
                    row=i, col=1
                )
        
        fig.update_layout(
            height=250 * n_vars,
            title_text="<b>Variable Distributions by Region</b>",
            barmode='overlay'
        )
    else:
        fig = make_subplots(
            rows=2, cols=2,
            subplot_titles=[v.replace('_', ' ').title() for v in variables[:4]]
        )
        
        positions = [(1, 1), (1, 2), (2, 1), (2, 2)]
        for var, (row, col) in zip(variables[:4], positions):
            fig.add_trace(
                go.Histogram(x=df[var], name=var, showlegend=False),
                row=row, col=col
            )
        
        fig.update_layout(
            height=600,
            title_text="<b>Variable Distributions</b>"
        )
    
    return fig


# =============================================================================
# MAIN EXECUTION (for testing)
# =============================================================================

if __name__ == "__main__":
    print("Testing EDA module...")
    
    # Test ecological fallacy demo
    fig = demonstrate_ecological_fallacy()
    plt.show()
    
    print("\nEcological fallacy demonstration complete.")
    print("See the figure for the key teaching point.")
