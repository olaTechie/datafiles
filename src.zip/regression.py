"""
Regression Analysis Module
==========================

Comprehensive regression analysis with:
- Progressive/hierarchical modelling
- Full diagnostic testing
- Sensitivity analysis
- Robust standard errors

TEACHING NOTES:
--------------
1. WHY PROGRESSIVE MODELLING?
   Building models in stages (Distal → Intermediate → Proximate) helps:
   - Identify mediation (do distal effects work through proximate?)
   - Detect confounding (do coefficients change when adjusting?)
   - Understand causal pathways (which factors are most proximal?)

2. KEY DIAGNOSTIC TESTS:
   - VIF: Multicollinearity (VIF > 5-10 is problematic)
   - Breusch-Pagan: Heteroscedasticity (non-constant variance)
   - Shapiro-Wilk: Normality of residuals
   - Cook's Distance: Influential observations
   
3. ROBUST STANDARD ERRORS:
   When heteroscedasticity is detected, use HC3 robust SEs.
   These are valid even when variance is non-constant.

4. ECOLOGICAL REGRESSION CAVEATS:
   - Results describe COUNTRY-LEVEL associations, not individual effects
   - Coefficients may be biased by aggregation (ecological bias)
   - Spatial autocorrelation violates independence assumption

Key References:
- Fox, J. (2015). Applied Regression Analysis and Generalized Linear Models.
- Wakefield, J. (2008). Ecologic studies revisited. Annual Review of Public Health.
- Long, J.S. & Ervin, L.H. (2000). Using Heteroscedasticity Consistent SEs.

Dependencies:
    pip install pandas numpy matplotlib seaborn scipy statsmodels scikit-learn
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
import statsmodels.api as sm
from statsmodels.stats.diagnostic import het_breuschpagan, het_white
from statsmodels.stats.outliers_influence import variance_inflation_factor, OLSInfluence
from statsmodels.stats.stattools import durbin_watson
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from typing import Dict, List, Optional, Tuple
import warnings

warnings.filterwarnings('ignore')


# =============================================================================
# PROGRESSIVE MODEL BUILDING
# =============================================================================

def build_progressive_models(
    df: pd.DataFrame,
    outcome: str = 'crude_death_rate',
    distal_vars: Optional[Dict] = None,
    intermediate_vars: Optional[Dict] = None,
    proximate_vars: Optional[Dict] = None,
    test_size: float = 0.2,
    impute_missing: bool = True
) -> Tuple[pd.DataFrame, Dict]:
    """
    Builds hierarchical regression models to demonstrate mediation.
    
    TEACHING SCRIPT:
    ---------------
    "We build THREE models to understand causal pathways:
    
    MODEL 1 (Distal Only):
    - Includes root causes: GNI, education, inequality
    - Shows 'total effect' of socioeconomic factors
    
    MODEL 2 (Distal + Intermediate):
    - Adds systems factors: healthcare capacity, infrastructure
    - Watch for changes in distal coefficients!
    - If distal effects shrink → intermediate factors MEDIATE the effect
    
    MODEL 3 (Full Model):
    - Adds proximate factors: disease burden, risk factors
    - Shows 'direct effects' after accounting for mediators
    
    INTERPRETATION:
    If education coefficient drops from Model 1 to Model 3,
    education's effect works THROUGH better healthcare and lower disease burden."
    
    Parameters
    ----------
    df : pd.DataFrame
        Dataset with all variables
    outcome : str
        Name of outcome variable
    distal_vars : dict, optional
        Distal variable code-to-name mapping
    intermediate_vars : dict, optional
        Intermediate variable code-to-name mapping
    proximate_vars : dict, optional
        Proximate variable code-to-name mapping
    test_size : float
        Proportion for test set
    impute_missing : bool
        Whether to impute missing predictor values
        
    Returns
    -------
    tuple : (comparison_df, dict of fitted models)
    """
    
    # Default variable sets if not provided
    # Note: These are {column_name: display_name} mappings
    if distal_vars is None:
        distal_vars = {
            'gni_per_capita': 'GNI per Capita',
            'adult_literacy': 'Adult Literacy',
            'gini_index': 'Inequality (Gini)'
        }
    
    if intermediate_vars is None:
        intermediate_vars = {
            'physicians_density': 'Physicians Density',
            'safe_water': 'Safe Water Access',
            'basic_sanitation': 'Basic Sanitation'
        }
    
    if proximate_vars is None:
        proximate_vars = {
            'communicable_disease_deaths': 'Communicable Disease %',
            'ncd_mortality_pct': 'NCD Mortality %',
            'measles_immunisation': 'Measles Immunisation'
        }
    
    # Debug: Print what we received
    print(f"\n🔍 DEBUG: Checking variable dictionaries...")
    print(f"   Distal vars type: {type(distal_vars)}")
    print(f"   Distal vars sample: {list(distal_vars.items())[:3] if distal_vars else 'None'}")
    print(f"   DataFrame columns: {list(df.columns)[:10]}...")
    
    # Extract variable names from dictionaries
    # The dictionaries from data_acquisition have format {WB_code: friendly_name}
    # We need the friendly_names (values) which are the actual column names
    def extract_var_names(var_dict, dict_name=""):
        """Extract variable names - handles both {code: name} and {name: label} formats"""
        if var_dict is None:
            print(f"   {dict_name}: None provided")
            return []
        
        var_names = []
        df_cols = list(df.columns)
        
        # First, check if the values are in the dataframe (standard format from data_acquisition)
        for v in var_dict.values():
            if v in df_cols:
                var_names.append(v)
        
        # If none found, check if keys are in the dataframe (alternative format)
        if len(var_names) == 0:
            for k in var_dict.keys():
                if k in df_cols:
                    var_names.append(k)
        
        print(f"   {dict_name}: Found {len(var_names)} variables: {var_names[:5]}{'...' if len(var_names) > 5 else ''}")
        return var_names
    
    # Get available variables
    available_distal = extract_var_names(distal_vars, "Distal")
    available_intermediate = extract_var_names(intermediate_vars, "Intermediate")
    available_proximate = extract_var_names(proximate_vars, "Proximate")
    
    all_features = available_distal + available_intermediate + available_proximate
    
    if len(all_features) == 0:
        raise ValueError("No valid features found in dataset")
    
    print("\n" + "=" * 70)
    print("📊 PROGRESSIVE REGRESSION ANALYSIS")
    print("=" * 70)
    print(f"\nOutcome: {outcome}")
    print(f"Distal variables: {available_distal}")
    print(f"Intermediate variables: {available_intermediate}")
    print(f"Proximate variables: {available_proximate}")
    
    # Prepare data
    df_model = df[[outcome] + all_features].copy()
    
    # Impute missing values in predictors
    if impute_missing:
        imputer = SimpleImputer(strategy='median')
        df_model[all_features] = imputer.fit_transform(df_model[all_features])
    
    # Drop rows with missing outcome
    df_model = df_model.dropna(subset=[outcome])
    
    print(f"\nObservations used: {len(df_model)}")
    
    # Split data
    X = df_model[all_features]
    y = df_model[outcome]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=42
    )
    
    # Define model specifications
    models_spec = {
        'Model 1: Distal Only': available_distal,
        'Model 2: Distal + Intermediate': available_distal + available_intermediate,
        'Model 3: Full Model': all_features
    }
    
    # Fit models
    results = []
    fitted_models = {}
    
    for model_name, features in models_spec.items():
        if len(features) == 0:
            continue
        
        # Add constant
        X_train_model = sm.add_constant(X_train[features])
        X_test_model = sm.add_constant(X_test[features])
        
        # Fit OLS
        model = sm.OLS(y_train, X_train_model).fit()
        
        # Predictions for test set
        y_pred = model.predict(X_test_model)
        test_r2 = 1 - np.sum((y_test - y_pred)**2) / np.sum((y_test - y_test.mean())**2)
        
        results.append({
            'Model': model_name,
            'R²': model.rsquared,
            'Adj. R²': model.rsquared_adj,
            'Test R²': test_r2,
            'AIC': model.aic,
            'BIC': model.bic,
            'Num. Features': len(features),
            'F-statistic': model.fvalue,
            'F p-value': model.f_pvalue
        })
        
        fitted_models[model_name] = model
    
    # Create comparison table
    results_df = pd.DataFrame(results)
    
    print("\n" + "=" * 70)
    print("📈 MODEL COMPARISON")
    print("=" * 70)
    print(results_df.to_string(index=False, float_format=lambda x: f"{x:.4f}"))
    
    # Print full model summary
    print("\n" + "=" * 70)
    print("📋 FULL MODEL DETAILED RESULTS")
    print("=" * 70)
    
    full_model = fitted_models.get('Model 3: Full Model') or list(fitted_models.values())[-1]
    print(full_model.summary())
    
    # Teaching interpretation
    print("\n" + "=" * 70)
    print("💡 TEACHING INTERPRETATION GUIDE")
    print("=" * 70)
    
    print("\n1. MODEL FIT PROGRESSION:")
    print("   - Does R² increase substantially with each model?")
    print("   - If yes: each determinant level adds explanatory power")
    print("   - If no: later factors may be collinear with earlier ones")
    
    print("\n2. COEFFICIENT CHANGES (Mediation Check):")
    print("   Compare distal coefficients across models:")
    
    if len(fitted_models) >= 2:
        m1_coefs = fitted_models['Model 1: Distal Only'].params
        m3_coefs = list(fitted_models.values())[-1].params
        
        for var in available_distal:
            if var in m1_coefs.index and var in m3_coefs.index:
                change_pct = (m3_coefs[var] - m1_coefs[var]) / abs(m1_coefs[var]) * 100 if m1_coefs[var] != 0 else 0
                direction = "↓ ATTENUATED" if change_pct < -20 else "↑ STRENGTHENED" if change_pct > 20 else "→ STABLE"
                print(f"   - {var}: {direction} ({change_pct:+.1f}%)")
    
    print("\n3. STATISTICAL SIGNIFICANCE (p < 0.05):")
    print("   Which factors remain significant in the full model?")
    
    sig_vars = full_model.pvalues[full_model.pvalues < 0.05].index.tolist()
    sig_vars = [v for v in sig_vars if v != 'const']
    print(f"   Significant: {sig_vars}")
    
    print("=" * 70)
    
    return results_df, fitted_models


# =============================================================================
# DIAGNOSTIC TESTS
# =============================================================================

def regression_diagnostics(
    model: sm.regression.linear_model.RegressionResultsWrapper,
    X: pd.DataFrame,
    show_plots: bool = True
) -> Dict:
    """
    Comprehensive diagnostic tests for OLS regression.
    
    TEACHING SCRIPT:
    ---------------
    "Before trusting our results, we check OLS assumptions:
    
    1. LINEARITY: Residuals vs. fitted should show no pattern
       - Pattern → consider non-linear terms or transformation
    
    2. HOMOSCEDASTICITY: Constant variance of residuals
       - Breusch-Pagan test: H₀ = constant variance
       - p < 0.05 → heteroscedasticity → use robust SEs
    
    3. NORMALITY: Residuals should be approximately normal
       - Shapiro-Wilk test: H₀ = normal distribution
       - QQ plot should follow diagonal
       - Slight deviations OK with large samples (CLT)
    
    4. INDEPENDENCE: No autocorrelation in residuals
       - Durbin-Watson: ~2 is good, <1.5 or >2.5 problematic
       - For spatial data: use Moran's I on residuals
    
    5. MULTICOLLINEARITY: Predictors shouldn't be too correlated
       - VIF > 5: moderate collinearity
       - VIF > 10: severe collinearity → drop or combine variables"
    
    Parameters
    ----------
    model : statsmodels RegressionResults
        Fitted OLS model
    X : pd.DataFrame
        Design matrix (with constant)
    show_plots : bool
        Whether to display diagnostic plots
        
    Returns
    -------
    dict : Diagnostic test results
    """
    
    results = {}
    
    # Get residuals and fitted values
    residuals = model.resid
    fitted = model.fittedvalues
    
    print("\n" + "=" * 70)
    print("🔬 REGRESSION DIAGNOSTICS")
    print("=" * 70)
    
    # 1. Multicollinearity (VIF)
    print("\n1️⃣ MULTICOLLINEARITY (Variance Inflation Factors)")
    print("-" * 50)
    
    # Calculate VIF for each variable (excluding constant)
    X_no_const = X.drop('const', axis=1, errors='ignore')
    
    vif_data = []
    for i, col in enumerate(X_no_const.columns):
        vif = variance_inflation_factor(X_no_const.values, i)
        vif_data.append({'Variable': col, 'VIF': vif})
        status = "⚠️ HIGH" if vif > 10 else "⚡ MODERATE" if vif > 5 else "✅ OK"
        print(f"   {col}: {vif:.2f} {status}")
    
    results['vif'] = pd.DataFrame(vif_data)
    
    max_vif = max([v['VIF'] for v in vif_data])
    if max_vif > 10:
        print("\n   ⚠️  SEVERE multicollinearity detected!")
        print("   Consider removing or combining highly correlated variables.")
    elif max_vif > 5:
        print("\n   ⚡ Moderate multicollinearity - monitor coefficient stability")
    else:
        print("\n   ✅ No concerning multicollinearity")
    
    # 2. Heteroscedasticity (Breusch-Pagan)
    print("\n2️⃣ HETEROSCEDASTICITY (Breusch-Pagan Test)")
    print("-" * 50)
    
    bp_test = het_breuschpagan(residuals, X)
    results['breusch_pagan'] = {
        'LM_statistic': bp_test[0],
        'LM_pvalue': bp_test[1],
        'F_statistic': bp_test[2],
        'F_pvalue': bp_test[3]
    }
    
    print(f"   LM statistic: {bp_test[0]:.4f}")
    print(f"   LM p-value:   {bp_test[1]:.4f}")
    
    if bp_test[1] < 0.05:
        print("\n   ⚠️  Heteroscedasticity DETECTED (p < 0.05)")
        print("   → Standard errors may be biased")
        print("   → Use robust (HC3) standard errors")
        results['heteroscedasticity_detected'] = True
    else:
        print("\n   ✅ No significant heteroscedasticity")
        results['heteroscedasticity_detected'] = False
    
    # 3. Normality of Residuals (Shapiro-Wilk)
    print("\n3️⃣ NORMALITY OF RESIDUALS (Shapiro-Wilk Test)")
    print("-" * 50)
    
    # Shapiro-Wilk limited to 5000 observations
    resid_sample = residuals[:5000] if len(residuals) > 5000 else residuals
    shapiro_stat, shapiro_p = stats.shapiro(resid_sample)
    
    results['shapiro_wilk'] = {
        'statistic': shapiro_stat,
        'p_value': shapiro_p
    }
    
    print(f"   Shapiro-Wilk statistic: {shapiro_stat:.4f}")
    print(f"   P-value: {shapiro_p:.4f}")
    
    if shapiro_p < 0.05:
        print("\n   ⚠️  Residuals may not be normally distributed")
        print("   → With large samples, this is often acceptable (CLT)")
        print("   → Consider transforming outcome if severely skewed")
    else:
        print("\n   ✅ Residuals approximately normal")
    
    # Additional normality metrics
    skew = stats.skew(residuals)
    kurt = stats.kurtosis(residuals)
    print(f"\n   Skewness: {skew:.3f} (ideal: 0)")
    print(f"   Kurtosis: {kurt:.3f} (ideal: 0, i.e., mesokurtic)")
    
    # 4. Independence (Durbin-Watson)
    print("\n4️⃣ INDEPENDENCE (Durbin-Watson Test)")
    print("-" * 50)
    
    dw_stat = durbin_watson(residuals)
    results['durbin_watson'] = dw_stat
    
    print(f"   Durbin-Watson statistic: {dw_stat:.4f}")
    print(f"   (Ideal ≈ 2; <1.5 or >2.5 indicates autocorrelation)")
    
    if dw_stat < 1.5:
        print("\n   ⚠️  Positive autocorrelation suspected")
    elif dw_stat > 2.5:
        print("\n   ⚠️  Negative autocorrelation suspected")
    else:
        print("\n   ✅ No strong evidence of autocorrelation")
    
    print("\n   Note: For spatial data, also check Moran's I on residuals!")
    
    print("=" * 70)
    
    # Create diagnostic plots
    if show_plots:
        fig, axes = plt.subplots(2, 2, figsize=(12, 10))
        
        # Plot 1: Residuals vs Fitted
        axes[0, 0].scatter(fitted, residuals, alpha=0.5)
        axes[0, 0].axhline(y=0, color='r', linestyle='--')
        axes[0, 0].set_xlabel('Fitted Values')
        axes[0, 0].set_ylabel('Residuals')
        axes[0, 0].set_title('Residuals vs Fitted\n(Check for patterns)')
        
        # Add lowess smooth
        try:
            from statsmodels.nonparametric.smoothers_lowess import lowess
            smooth = lowess(residuals, fitted, frac=0.3)
            axes[0, 0].plot(smooth[:, 0], smooth[:, 1], 'r-', linewidth=2)
        except:
            pass
        
        # Plot 2: QQ Plot
        stats.probplot(residuals, dist="norm", plot=axes[0, 1])
        axes[0, 1].set_title('Normal Q-Q Plot\n(Should follow diagonal)')
        
        # Plot 3: Scale-Location (sqrt of standardised residuals)
        std_residuals = residuals / np.std(residuals)
        axes[1, 0].scatter(fitted, np.sqrt(np.abs(std_residuals)), alpha=0.5)
        axes[1, 0].set_xlabel('Fitted Values')
        axes[1, 0].set_ylabel('√|Standardised Residuals|')
        axes[1, 0].set_title('Scale-Location Plot\n(Check for heteroscedasticity)')
        
        # Plot 4: Residual Distribution
        axes[1, 1].hist(residuals, bins=30, density=True, alpha=0.7, edgecolor='black')
        
        # Overlay normal distribution
        x_range = np.linspace(residuals.min(), residuals.max(), 100)
        axes[1, 1].plot(x_range, stats.norm.pdf(x_range, residuals.mean(), residuals.std()),
                        'r-', linewidth=2, label='Normal')
        axes[1, 1].set_xlabel('Residuals')
        axes[1, 1].set_ylabel('Density')
        axes[1, 1].set_title('Residual Distribution\n(Should be bell-shaped)')
        axes[1, 1].legend()
        
        plt.tight_layout()
        plt.show()
        
        results['diagnostic_figure'] = fig
    
    return results


# =============================================================================
# SENSITIVITY ANALYSIS
# =============================================================================

def sensitivity_analysis(
    model: sm.regression.linear_model.RegressionResultsWrapper,
    X: pd.DataFrame,
    y: pd.Series,
    df_original: pd.DataFrame = None
) -> Tuple[pd.DataFrame, go.Figure]:
    """
    Identifies influential observations using Cook's Distance.
    
    TEACHING SCRIPT:
    ---------------
    "Ecological analyses often have small samples (n ≈ 150-200 countries).
    A single unusual country can dramatically affect results.
    
    COOK'S DISTANCE measures influence - how much coefficients change
    if we remove each observation.
    
    Rule of thumb:
    - Cook's D > 4/n: Potentially influential
    - Cook's D > 1: Definitely investigate
    
    For influential observations, ask:
    1. Is the data correct? (Check the source)
    2. Is the country special? (Conflict, disaster, unique history)
    3. How do results change without it?"
    
    Parameters
    ----------
    model : statsmodels RegressionResults
        Fitted OLS model
    X : pd.DataFrame
        Design matrix
    y : pd.Series
        Outcome values
    df_original : pd.DataFrame, optional
        Original data for country names
        
    Returns
    -------
    tuple : (influential_observations_df, diagnostic_figure)
    """
    
    print("\n" + "=" * 70)
    print("🔍 SENSITIVITY ANALYSIS (Influential Observations)")
    print("=" * 70)
    
    # Calculate influence measures
    influence = OLSInfluence(model)
    
    # Cook's distance
    cooks_d = influence.cooks_distance[0]
    
    # Threshold
    n = len(y)
    threshold = 4 / n
    
    # Identify influential observations
    influential_idx = np.where(cooks_d > threshold)[0]
    
    print(f"\nThreshold (4/n): {threshold:.4f}")
    print(f"Observations above threshold: {len(influential_idx)}")
    
    # Create results dataframe
    results_data = []
    for idx in influential_idx:
        obs_data = {
            'Index': idx,
            'Cooks_D': cooks_d[idx],
            'Outcome_Value': y.iloc[idx]
        }
        
        # Add country name if available
        if df_original is not None and 'country' in df_original.columns:
            try:
                obs_data['Country'] = df_original.iloc[idx]['country']
            except:
                obs_data['Country'] = 'Unknown'
        
        results_data.append(obs_data)
    
    influential_df = pd.DataFrame(results_data).sort_values('Cooks_D', ascending=False)
    
    if len(influential_df) > 0:
        print("\n📍 INFLUENTIAL OBSERVATIONS:")
        print(influential_df.to_string(index=False))
    else:
        print("\n✅ No highly influential observations detected")
    
    # Leave-one-out analysis for top influential observations
    if len(influential_idx) > 0:
        print("\n📊 LEAVE-ONE-OUT COEFFICIENT STABILITY:")
        print("-" * 50)
        
        original_coefs = model.params
        
        for idx in influential_idx[:5]:  # Top 5 most influential
            # Refit without this observation
            X_loo = X.drop(X.index[idx])
            y_loo = y.drop(y.index[idx])
            
            model_loo = sm.OLS(y_loo, X_loo).fit()
            
            # Calculate coefficient changes
            coef_changes = (model_loo.params - original_coefs) / np.abs(original_coefs) * 100
            coef_changes = coef_changes.drop('const', errors='ignore')
            
            max_change_var = coef_changes.abs().idxmax()
            max_change = coef_changes[max_change_var]
            
            country = influential_df.loc[influential_df['Index'] == idx, 'Country'].values
            country = country[0] if len(country) > 0 else f'Obs {idx}'
            
            print(f"\n   Without {country}:")
            print(f"   Max coefficient change: {max_change_var} ({max_change:+.1f}%)")
    
    # Create diagnostic plot
    fig = make_subplots(
        rows=1, cols=2,
        subplot_titles=(
            '<b>Cook\'s Distance by Observation</b>',
            '<b>Residuals vs Leverage</b>'
        )
    )
    
    # Cook's distance plot
    colors = ['red' if d > threshold else 'steelblue' for d in cooks_d]
    
    fig.add_trace(
        go.Bar(
            x=list(range(len(cooks_d))),
            y=cooks_d,
            marker_color=colors,
            name="Cook's D",
            showlegend=False
        ),
        row=1, col=1
    )
    
    fig.add_hline(y=threshold, line_dash='dash', line_color='red',
                  annotation_text=f'Threshold (4/n = {threshold:.4f})',
                  row=1, col=1)
    
    # Residuals vs Leverage plot
    leverage = influence.hat_matrix_diag
    std_residuals = influence.resid_studentized_internal
    
    fig.add_trace(
        go.Scatter(
            x=leverage,
            y=std_residuals,
            mode='markers',
            marker=dict(
                size=cooks_d * 1000,  # Size by Cook's D
                sizemin=3,
                color=cooks_d,
                colorscale='Reds',
                showscale=True,
                colorbar=dict(title="Cook's D", x=1.02)
            ),
            name='Observations',
            showlegend=False
        ),
        row=1, col=2
    )
    
    fig.update_xaxes(title_text='Observation Index', row=1, col=1)
    fig.update_yaxes(title_text="Cook's Distance", row=1, col=1)
    fig.update_xaxes(title_text='Leverage', row=1, col=2)
    fig.update_yaxes(title_text='Studentised Residuals', row=1, col=2)
    
    fig.update_layout(
        height=450,
        title_text="<b>Sensitivity Analysis: Influential Observations</b>"
    )
    
    print("\n" + "=" * 70)
    
    return influential_df, fig


# =============================================================================
# ROBUST STANDARD ERRORS
# =============================================================================

def robust_standard_errors(
    model: sm.regression.linear_model.RegressionResultsWrapper,
    cov_type: str = 'HC3'
) -> pd.DataFrame:
    """
    Recomputes standard errors using heteroscedasticity-robust estimators.
    
    TEACHING SCRIPT:
    ---------------
    "When we detect heteroscedasticity, standard OLS standard errors
    are WRONG - usually too small, leading to false positives.
    
    Robust standard errors (also called 'sandwich' estimators) are valid
    even when variance is non-constant.
    
    HC3 is recommended because:
    - Works well in small samples
    - Slightly conservative (better for avoiding false positives)
    - Default in many statistical packages
    
    The coefficients don't change - only the standard errors and p-values."
    
    Parameters
    ----------
    model : statsmodels RegressionResults
        Fitted OLS model
    cov_type : str
        Type of robust covariance: 'HC0', 'HC1', 'HC2', 'HC3'
        HC3 is recommended for small samples
        
    Returns
    -------
    pd.DataFrame : Comparison of standard vs robust results
    """
    
    print("\n" + "=" * 70)
    print(f"🛡️ ROBUST STANDARD ERRORS ({cov_type})")
    print("=" * 70)
    
    # Get robust results
    robust_model = model.get_robustcov_results(cov_type=cov_type)
    
    # Create comparison table
    comparison = pd.DataFrame({
        'Variable': model.params.index,
        'Coefficient': model.params.values,
        'Std SE': model.bse.values,
        'Std p-value': model.pvalues.values,
        'Robust SE': robust_model.bse.values,
        'Robust p-value': robust_model.pvalues.values
    })
    
    # Calculate changes
    comparison['SE_change_%'] = (
        (comparison['Robust SE'] - comparison['Std SE']) / comparison['Std SE'] * 100
    )
    
    # Flag significance changes
    comparison['Sig_change'] = ''
    for idx in comparison.index:
        std_sig = comparison.loc[idx, 'Std p-value'] < 0.05
        rob_sig = comparison.loc[idx, 'Robust p-value'] < 0.05
        if std_sig and not rob_sig:
            comparison.loc[idx, 'Sig_change'] = '⚠️ Lost'
        elif not std_sig and rob_sig:
            comparison.loc[idx, 'Sig_change'] = '✨ Gained'
    
    print("\nComparison of Standard vs. Robust Standard Errors:")
    print(comparison.to_string(index=False, float_format=lambda x: f"{x:.4f}"))
    
    # Summary
    se_increased = (comparison['SE_change_%'] > 0).sum()
    sig_lost = (comparison['Sig_change'] == '⚠️ Lost').sum()
    
    print(f"\n📊 SUMMARY:")
    print(f"   Variables with increased SE: {se_increased} / {len(comparison)}")
    print(f"   Variables losing significance: {sig_lost}")
    
    if sig_lost > 0:
        print("\n   ⚠️  Some results are less robust than they appeared!")
        print("   Report robust standard errors in publications.")
    else:
        print("\n   ✅ Results are stable - robust SEs confirm findings")
    
    print("=" * 70)
    
    return comparison


# =============================================================================
# MAIN EXECUTION (for testing)
# =============================================================================

if __name__ == "__main__":
    print("Testing regression module...")
    print("\nThis module requires data from data_acquisition module.")
    print("See notebooks for complete usage examples.")
